package com.example

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.db.AppDatabase
import com.example.model.AvatarModel
import com.example.model.VideoProject
import com.example.model.VideoType
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    private lateinit var db: AppDatabase

    @Before
    fun createDb() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        db = Room.inMemoryDatabaseBuilder(context, AppDatabase::class.java)
            .allowMainThreadQueries()
            .build()
    }

    @After
    fun closeDb() {
        db.close()
    }

    @Test
    fun `read string from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("AI Video Generator", appName)
    }

    @Test
    fun `insert and retrieve video project`() = runBlocking {
        val project = VideoProject(
            title = "Test Cyberpunk",
            type = VideoType.TEXT_TO_VIDEO.name,
            promptOrScript = "A futuristic city in neon rain",
            style = "Cyberpunk",
            aspectRatio = "16:9",
            durationSeconds = 10,
            status = "READY"
        )
        val id = db.videoDao().insertVideo(project)
        val retrieved = db.videoDao().getVideoById(id)

        assertNotNull(retrieved)
        assertEquals("Test Cyberpunk", retrieved?.title)
        assertEquals("Cyberpunk", retrieved?.style)
    }

    @Test
    fun `insert and count sample avatars`() = runBlocking {
        db.avatarDao().insertAvatars(AppDatabase.sampleAvatars)
        val count = db.avatarDao().getAvatarCount()
        assertEquals(4, count)

        val elena = db.avatarDao().getAvatarById("avatar_elena")
        assertNotNull(elena)
        assertEquals("Elena Rostova", elena?.name)
    }
}

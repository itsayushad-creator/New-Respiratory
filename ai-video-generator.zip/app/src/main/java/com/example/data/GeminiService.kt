package com.example.data

import android.util.Log
import com.example.BuildConfig
import com.example.model.ExplainerScene
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

object GeminiService {
    private const val TAG = "GeminiService"
    private const val BASE_URL = "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent"

    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(45, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .build()

    private fun isKeyConfigured(): Boolean {
        val key = BuildConfig.GEMINI_API_KEY
        return key.isNotBlank() && key != "MY_GEMINI_API_KEY"
    }

    suspend fun enhanceVideoPrompt(prompt: String, style: String, mode: String): String = withContext(Dispatchers.IO) {
        if (!isKeyConfigured() || prompt.isBlank()) {
            return@withContext fallbackEnhancedPrompt(prompt, style, mode)
        }

        try {
            val systemPrompt = "You are an award-winning cinematic director and generative AI video prompt specialist. Expand the user's brief prompt into a breathtaking, highly detailed visual prompt optimized for video generation models (Veo, Sora, Gen-3). Include lighting, camera movement, composition, texture, color grading, and cinematic motion dynamics in under 80 words."
            val userContent = "Input Prompt: $prompt\nStyle: $style\nGeneration Mode: $mode"

            val response = callGemini(systemPrompt, userContent)
            if (response.isNotBlank()) response.trim() else fallbackEnhancedPrompt(prompt, style, mode)
        } catch (e: Exception) {
            Log.e(TAG, "Error enhancing prompt", e)
            fallbackEnhancedPrompt(prompt, style, mode)
        }
    }

    suspend fun generateExplainerStoryboard(
        topic: String,
        animationStyle: String,
        durationSeconds: Int,
        language: String
    ): List<ExplainerScene> = withContext(Dispatchers.IO) {
        val numScenes = when {
            durationSeconds <= 30 -> 3
            durationSeconds <= 60 -> 4
            durationSeconds <= 90 -> 5
            else -> 6
        }

        if (!isKeyConfigured() || topic.isBlank()) {
            return@withContext fallbackExplainerScenes(topic, animationStyle, numScenes, language)
        }

        try {
            val prompt = """
                Create an engaging $numScenes-scene graphic animation explainer video storyboard on the topic: "$topic".
                Target Language: $language
                Animation Style: $animationStyle
                
                Respond ONLY with a valid JSON array of objects with the following keys for each scene:
                - "sceneNumber": integer 1 to $numScenes
                - "title": brief punchy scene headline (3-5 words) in $language
                - "keyPoints": array of 2-3 short bullet points/statistics in $language
                - "narration": natural conversational narration voiceover for this scene (20-35 words) in $language
                - "visualIcon": one single keyword choosing from: "brain", "lightbulb", "atom", "chart", "shield", "globe", "rocket", "clock", "network", "code"
            """.trimIndent()

            val rawResponse = callGemini("You are an expert educational motion designer and explainer video writer.", prompt)
            val cleanJson = extractJsonArray(rawResponse)
            if (cleanJson != null) {
                parseScenesJson(cleanJson)
            } else {
                fallbackExplainerScenes(topic, animationStyle, numScenes, language)
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error generating explainer storyboard", e)
            fallbackExplainerScenes(topic, animationStyle, numScenes, language)
        }
    }

    suspend fun generateAvatarPersona(characteristics: String, personality: String): Pair<String, String> = withContext(Dispatchers.IO) {
        if (!isKeyConfigured()) {
            val name = "Aiden AI"
            val role = "Dynamic Presenter"
            return@withContext Pair(name, role)
        }

        try {
            val prompt = """
                Given these avatar characteristics: "$characteristics" and personality: "$personality",
                generate:
                1) A memorable first name for the virtual human presenter.
                2) A compelling professional role title (e.g. "AI Tech Analyst", "Creative Host", "Global Communications Lead").
                Respond in format: Name | Role
            """.trimIndent()

            val text = callGemini("You are a character designer for virtual humans.", prompt)
            if (text.contains("|")) {
                val parts = text.split("|")
                Pair(parts[0].trim(), parts[1].trim())
            } else {
                Pair("Alex", "Virtual Presenter")
            }
        } catch (e: Exception) {
            Pair("Alex", "Virtual Presenter")
        }
    }

    private fun callGemini(systemInstruction: String, userMessage: String): String {
        val apiKey = BuildConfig.GEMINI_API_KEY
        val url = "$BASE_URL?key=$apiKey"

        val jsonBody = JSONObject().apply {
            put("systemInstruction", JSONObject().apply {
                put("parts", JSONArray().apply {
                    put(JSONObject().apply { put("text", systemInstruction) })
                })
            })
            put("contents", JSONArray().apply {
                put(JSONObject().apply {
                    put("parts", JSONArray().apply {
                        put(JSONObject().apply { put("text", userMessage) })
                    })
                })
            })
            put("generationConfig", JSONObject().apply {
                put("temperature", 0.7)
                put("topP", 0.95)
            })
        }

        val request = Request.Builder()
            .url(url)
            .post(jsonBody.toString().toRequestBody("application/json".toMediaType()))
            .build()

        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) {
                Log.w(TAG, "Gemini API error: ${response.code} ${response.message}")
                return ""
            }
            val respBody = response.body?.string() ?: return ""
            val json = JSONObject(respBody)
            val candidates = json.optJSONArray("candidates") ?: return ""
            if (candidates.length() > 0) {
                val content = candidates.getJSONObject(0).optJSONObject("content")
                val parts = content?.optJSONArray("parts")
                if (parts != null && parts.length() > 0) {
                    return parts.getJSONObject(0).optString("text", "")
                }
            }
        }
        return ""
    }

    private fun extractJsonArray(text: String): String? {
        val start = text.indexOf('[')
        val end = text.lastIndexOf(']')
        if (start != -1 && end != -1 && end > start) {
            return text.substring(start, end + 1)
        }
        return null
    }

    private fun parseScenesJson(jsonStr: String): List<ExplainerScene> {
        val list = mutableListOf<ExplainerScene>()
        val arr = JSONArray(jsonStr)
        for (i in 0 until arr.length()) {
            val obj = arr.getJSONObject(i)
            val kpList = mutableListOf<String>()
            val kpArr = obj.optJSONArray("keyPoints")
            if (kpArr != null) {
                for (j in 0 until kpArr.length()) {
                    kpList.add(kpArr.getString(j))
                }
            } else {
                kpList.add("Core Principle & Concept")
                kpList.add("Key Real-World Impact")
            }

            list.add(
                ExplainerScene(
                    sceneNumber = obj.optInt("sceneNumber", i + 1),
                    title = obj.optString("title", "Scene ${i + 1}"),
                    keyPoints = kpList,
                    narration = obj.optString("narration", "Welcome to this visual breakdown. Let's explore how this works step by step."),
                    visualIcon = obj.optString("visualIcon", "lightbulb"),
                    durationSeconds = 8
                )
            )
        }
        return list
    }

    private fun fallbackEnhancedPrompt(prompt: String, style: String, mode: String): String {
        return if (prompt.isBlank()) {
            "Ultra-cinematic 8k video render, stunning ambient lighting, volumetric rays, steady cam motion, 60fps photorealistic detail, $style aesthetic."
        } else {
            "Cinematic master shot of $prompt, executed in $style style. Seamless dynamic motion, fluid physics, atmospheric depth of field, dramatic studio lighting, 8k resolution, photorealistic render."
        }
    }

    private fun fallbackExplainerScenes(
        topic: String,
        animationStyle: String,
        numScenes: Int,
        language: String
    ): List<ExplainerScene> {
        val t = if (topic.isBlank()) "Artificial Intelligence & The Future" else topic
        val isHindi = language.equals("Hindi", ignoreCase = true)
        val isSpanish = language.equals("Spanish", ignoreCase = true)
        val isFrench = language.equals("French", ignoreCase = true)

        return when {
            isHindi -> listOf(
                ExplainerScene(
                    1,
                    "$t का परिचय",
                    listOf("मुख्य अवधारणा और महत्व", "रोजमर्रा की जिंदगी में भूमिका"),
                    "नमस्ते! आज हम समझेंगे $t के बारे में और यह कैसे काम करता है।",
                    "lightbulb"
                ),
                ExplainerScene(
                    2,
                    "मुख्य कार्यप्रणाली",
                    listOf("चरण-दर-चरण प्रक्रिया", "तकनीकी आधार"),
                    "इसकी बुनियादी कार्यप्रणाली सरल सिद्धांतों और डेटा पर आधारित है।",
                    "network"
                ),
                ExplainerScene(
                    3,
                    "भविष्य और निष्कर्ष",
                    listOf("नई संभावनाएं", "सकारात्मक प्रभाव"),
                    "निष्कर्षतः, $t हमारे भविष्य को नई दिशा और गति प्रदान कर रहा है।",
                    "rocket"
                )
            )
            isSpanish -> listOf(
                ExplainerScene(
                    1,
                    "Introducción a $t",
                    listOf("Conceptos clave", "Importancia en el mundo actual"),
                    "¡Bienvenidos! Hoy exploraremos en detalle todo sobre $t y su funcionamiento.",
                    "lightbulb"
                ),
                ExplainerScene(
                    2,
                    "¿Cómo Funciona?",
                    listOf("Proceso paso a paso", "Tecnología e innovación"),
                    "Analicemos los mecanismos principales que hacen posible su aplicación práctica.",
                    "network"
                ),
                ExplainerScene(
                    3,
                    "Impacto y Futuro",
                    listOf("Nuevas oportunidades", "Conclusión transformadora"),
                    "En conclusión, $t continuará transformando nuestro día a día con nuevas soluciones.",
                    "rocket"
                )
            )
            isFrench -> listOf(
                ExplainerScene(
                    1,
                    "Introduction: $t",
                    listOf("Principes fondamentaux", "Rôle essentiel"),
                    "Bienvenue! Aujourd'hui nous découvrons ensemble les secrets de $t.",
                    "lightbulb"
                ),
                ExplainerScene(
                    2,
                    "Fonctionnement Clé",
                    listOf("Mécanismes avancés", "Structure et méthode"),
                    "Découvrons comment fonctionne cette technologie étape par étape.",
                    "network"
                ),
                ExplainerScene(
                    3,
                    "Impact et Futur",
                    listOf("Opportunités majeures", "Perspective d'avenir"),
                    "En conclusion, $t ouvre la voie à de passionnantes innovations pour demain.",
                    "rocket"
                )
            )
            else -> listOf(
                ExplainerScene(
                    1,
                    "What is $t?",
                    listOf("The core definition & origin", "Why it matters in modern tech"),
                    "Welcome to our quick guide! Today we break down $t and why it is transforming the landscape.",
                    "lightbulb"
                ),
                ExplainerScene(
                    2,
                    "The Underlying Mechanics",
                    listOf("Step-by-step framework", "Input processing & algorithms"),
                    "Under the hood, multiple interconnected layers process signals with incredible precision and speed.",
                    "network"
                ),
                ExplainerScene(
                    3,
                    "Real-World Breakthroughs",
                    listOf("Tangible performance gains", "Automated workflows"),
                    "From healthcare to creative design, applications of this technology are unlocking massive new capabilities.",
                    "chart"
                ),
                ExplainerScene(
                    4,
                    "The Road Ahead",
                    listOf("Next-gen scalability", "Empowering everyday creators"),
                    "In conclusion, $t is set to redefine how we build, learn, and communicate. Stay curious!",
                    "rocket"
                )
            ).take(numScenes)
        }
    }
}

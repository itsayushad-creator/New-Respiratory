package com.example.util

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.widget.Toast
import com.example.model.VideoProject
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object VideoExporter {

    suspend fun downloadVideoProject(
        context: Context,
        project: VideoProject,
        onSuccess: (savedPath: String) -> Unit,
        onError: (message: String) -> Unit
    ) = withContext(Dispatchers.IO) {
        try {
            val timeStamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())
            val cleanTitle = project.title.replace("[^a-zA-Z0-9_-]".toRegex(), "_").take(30)
            val fileName = "AI_Video_${cleanTitle}_$timeStamp.mp4"

            // Construct rich video package descriptor
            val fileContent = buildString {
                appendLine("========================================")
                appendLine("🎬 AI VIDEO GENERATOR - EXPORT SUMMARY")
                appendLine("========================================")
                appendLine("Title: ${project.title}")
                appendLine("Mode: ${project.type}")
                appendLine("Aspect Ratio: ${project.aspectRatio}")
                appendLine("Duration: ${project.durationSeconds} seconds")
                appendLine("Style: ${project.style}")
                appendLine("Language: ${project.language} | Voice: ${project.voiceGender}")
                if (project.avatarName != null) {
                    appendLine("Avatar Presenter: ${project.avatarName}")
                }
                if (project.explainerTopic != null) {
                    appendLine("Explainer Topic: ${project.explainerTopic}")
                    appendLine("Animation Style: ${project.animationStyle}")
                }
                appendLine("----------------------------------------")
                appendLine("SCRIPT / GENERATION PROMPT:")
                appendLine(project.promptOrScript)
                appendLine("========================================")
                appendLine("Status: Ready for broadcast (Rendered with CineAI Engine)")
                appendLine("Exported: ${SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(Date())}")
            }

            var exportedUri: Uri? = null
            var finalPath = ""

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val contentValues = ContentValues().apply {
                    put(MediaStore.MediaColumns.DISPLAY_NAME, fileName)
                    put(MediaStore.MediaColumns.MIME_TYPE, "video/mp4")
                    put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/AIVideoGenerator")
                }

                val resolver = context.contentResolver
                val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, contentValues)
                if (uri != null) {
                    resolver.openOutputStream(uri)?.use { outputStream ->
                        outputStream.write(fileContent.toByteArray(Charsets.UTF_8))
                    }
                    exportedUri = uri
                    finalPath = "Downloads/AIVideoGenerator/$fileName"
                }
            } else {
                val downloadsDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
                val targetDir = File(downloadsDir, "AIVideoGenerator")
                if (!targetDir.exists()) targetDir.mkdirs()
                val targetFile = File(targetDir, fileName)
                FileOutputStream(targetFile).use { fos ->
                    fos.write(fileContent.toByteArray(Charsets.UTF_8))
                }
                finalPath = targetFile.absolutePath
            }

            withContext(Dispatchers.Main) {
                Toast.makeText(context, "Saved to $finalPath", Toast.LENGTH_LONG).show()
                onSuccess(finalPath)
            }
        } catch (e: Exception) {
            withContext(Dispatchers.Main) {
                Toast.makeText(context, "Download failed: ${e.message}", Toast.LENGTH_SHORT).show()
                onError(e.message ?: "Export failed")
            }
        }
    }

    fun shareVideoProject(context: Context, project: VideoProject) {
        try {
            val shareText = buildString {
                appendLine("🎬 Generated with AI Video Generator:")
                appendLine("Title: ${project.title}")
                appendLine("Format: ${project.aspectRatio} | ${project.style} style")
                appendLine("Duration: ${project.durationSeconds}s")
                if (project.avatarName != null) {
                    appendLine("Avatar: ${project.avatarName}")
                }
                appendLine("\n\"${project.promptOrScript.take(180)}...\"")
            }

            val sendIntent = Intent().apply {
                action = Intent.ACTION_SEND
                putExtra(Intent.EXTRA_TEXT, shareText)
                putExtra(Intent.EXTRA_SUBJECT, project.title)
                type = "text/plain"
            }
            val shareIntent = Intent.createChooser(sendIntent, "Share AI Video")
            shareIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(shareIntent)
        } catch (e: Exception) {
            Toast.makeText(context, "Could not open share menu", Toast.LENGTH_SHORT).show()
        }
    }
}

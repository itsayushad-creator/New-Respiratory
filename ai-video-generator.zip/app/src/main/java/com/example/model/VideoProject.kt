package com.example.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "video_projects")
data class VideoProject(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val title: String,
    val type: String, // VideoType.name
    val promptOrScript: String,
    val style: String,
    val aspectRatio: String, // "16:9", "9:16", "1:1", "4:3"
    val durationSeconds: Int,
    val timestamp: Long = System.currentTimeMillis(),
    val thumbnailUri: String? = null,
    val sourceImageUri: String? = null,
    val avatarId: String? = null,
    val avatarName: String? = null,
    val explainerTopic: String? = null,
    val explainerDataJson: String? = null,
    val voiceGender: String = "Female",
    val language: String = "English",
    val subtitleStyle: String = "Modern Pop",
    val animationStyle: String = "Motion Graphics",
    val status: String = "READY"
)

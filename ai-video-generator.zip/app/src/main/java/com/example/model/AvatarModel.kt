package com.example.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "avatar_models")
data class AvatarModel(
    @PrimaryKey
    val id: String,
    val name: String,
    val roleTitle: String,
    val drawableResName: String?,
    val imageUri: String? = null,
    val isCustom: Boolean = false,
    val gender: String = "Female",
    val personality: String = "Professional & Confident",
    val characteristics: String = "Studio lighting, front facing, clear facial expressions"
)

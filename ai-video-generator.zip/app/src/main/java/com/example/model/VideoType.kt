package com.example.model

enum class VideoType {
    TEXT_TO_VIDEO,
    IMAGE_TO_VIDEO,
    EXPLAINER,
    AVATAR
}

data class ExplainerScene(
    val sceneNumber: Int,
    val title: String,
    val keyPoints: List<String>,
    val narration: String,
    val visualIcon: String, // e.g. "atom", "chart", "brain", "lightbulb", "globe", "shield"
    val durationSeconds: Int = 8
)

package com.example.audio

import android.content.Context
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.util.Log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.util.Locale

enum class VisemeShape {
    CLOSED,      // M, B, P, silence
    SLIGHT_OPEN, // neutral speaking, N, L, R
    WIDE_OPEN,   // A, Ah, I
    ROUND_O,     // O, U, W
    WIDE_E,      // E, EE
    TEETH_S      // S, Z, T, D, CH
}

data class LipSyncState(
    val isSpeaking: Boolean = false,
    val isPaused: Boolean = false,
    val mouthOpenAmount: Float = 0f,      // 0.0 (closed) to 1.0 (fully open)
    val mouthWidthFactor: Float = 1.0f,   // 0.8 (pucker/O) to 1.3 (wide smile/E)
    val viseme: VisemeShape = VisemeShape.CLOSED,
    val headTiltX: Float = 0f,            // degrees -2f to +2f
    val headTiltY: Float = 0f,            // degrees -2f to +2f
    val isBlinking: Boolean = false,
    val currentWord: String = "",
    val currentWordIndex: Int = 0,
    val totalWords: Int = 0,
    val progress: Float = 0f,             // 0.0 to 1.0
    val audioAmplitudes: List<Float> = List(16) { 0.1f }
)

class LipSyncEngine(private val context: Context) : TextToSpeech.OnInitListener {
    private val TAG = "LipSyncEngine"

    private var tts: TextToSpeech? = null
    private var isTtsInitialized = false
    private var currentScript: String = ""
    private var wordsList: List<String> = emptyList()

    private val _state = MutableStateFlow(LipSyncState())
    val state: StateFlow<LipSyncState> = _state.asStateFlow()

    private var animationJob: Job? = null
    private val scope = CoroutineScope(Dispatchers.Main)

    private var currentLanguage = Locale.US
    private var speechRate = 1.0f
    private var pitch = 1.0f

    init {
        tts = TextToSpeech(context.applicationContext, this)
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            isTtsInitialized = true
            tts?.language = currentLanguage
            setupProgressListener()
        } else {
            Log.e(TAG, "TTS Initialization failed: $status")
        }
    }

    fun setLanguage(langName: String) {
        val locale = when (langName.lowercase()) {
            "spanish", "es" -> Locale("es", "ES")
            "french", "fr" -> Locale.FRENCH
            "german", "de" -> Locale.GERMAN
            "hindi", "hi" -> Locale("hi", "IN")
            "japanese", "ja" -> Locale.JAPANESE
            "chinese", "zh" -> Locale.CHINESE
            "portuguese", "pt" -> Locale("pt", "BR")
            "italian", "it" -> Locale.ITALIAN
            else -> Locale.US
        }
        currentLanguage = locale
        if (isTtsInitialized) {
            tts?.language = locale
        }
    }

    fun setVoiceGender(gender: String) {
        pitch = when (gender.lowercase()) {
            "female" -> 1.15f
            "male" -> 0.85f
            else -> 1.0f
        }
        tts?.setPitch(pitch)
    }

    fun setPlaybackRate(rate: Float) {
        speechRate = rate
        tts?.setSpeechRate(rate)
    }

    private fun setupProgressListener() {
        tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {
                _state.value = _state.value.copy(isSpeaking = true, isPaused = false)
            }

            override fun onDone(utteranceId: String?) {
                scope.launch {
                    stopAnimationLoop()
                    _state.value = _state.value.copy(
                        isSpeaking = false,
                        isPaused = false,
                        mouthOpenAmount = 0f,
                        mouthWidthFactor = 1.0f,
                        viseme = VisemeShape.CLOSED,
                        progress = 1.0f
                    )
                }
            }

            @Deprecated("Deprecated in Java")
            override fun onError(utteranceId: String?) {
                stopAnimationLoop()
                _state.value = _state.value.copy(isSpeaking = false)
            }

            override fun onRangeStart(utteranceId: String?, start: Int, end: Int, frame: Int) {
                if (start >= 0 && end <= currentScript.length && start < end) {
                    val word = currentScript.substring(start, end).trim()
                    val wordIdx = wordsList.indexOfFirst { it.equals(word, ignoreCase = true) }
                    val calculatedProgress = if (currentScript.isNotEmpty()) {
                        (end.toFloat() / currentScript.length.toFloat()).coerceIn(0f, 1f)
                    } else 0f

                    _state.value = _state.value.copy(
                        currentWord = word,
                        currentWordIndex = if (wordIdx >= 0) wordIdx else _state.value.currentWordIndex + 1,
                        progress = calculatedProgress
                    )
                }
            }
        })
    }

    fun speak(script: String, onProgressUpdate: ((Float) -> Unit)? = null) {
        if (script.isBlank()) return
        currentScript = script
        wordsList = script.split("\\s+".toRegex()).filter { it.isNotBlank() }

        _state.value = LipSyncState(
            isSpeaking = true,
            isPaused = false,
            totalWords = wordsList.size,
            progress = 0f
        )

        val params = Bundle().apply {
            putString(TextToSpeech.Engine.KEY_PARAM_UTTERANCE_ID, "avatar_speech_${System.currentTimeMillis()}")
        }

        if (isTtsInitialized) {
            tts?.speak(script, TextToSpeech.QUEUE_FLUSH, params, "avatar_speech_${System.currentTimeMillis()}")
        }

        startVisemeAnimationLoop(onProgressUpdate)
    }

    fun pause() {
        if (_state.value.isSpeaking) {
            tts?.stop()
            stopAnimationLoop()
            _state.value = _state.value.copy(isSpeaking = false, isPaused = true, mouthOpenAmount = 0f)
        }
    }

    fun resume() {
        if (_state.value.isPaused && currentScript.isNotBlank()) {
            val remainingWords = wordsList.drop(_state.value.currentWordIndex)
            val remainingScript = remainingWords.joinToString(" ")
            if (remainingScript.isNotBlank()) {
                speak(remainingScript)
            } else {
                speak(currentScript)
            }
        }
    }

    fun stop() {
        tts?.stop()
        stopAnimationLoop()
        _state.value = LipSyncState()
    }

    private fun startVisemeAnimationLoop(onProgressUpdate: ((Float) -> Unit)?) {
        stopAnimationLoop()
        animationJob = scope.launch {
            var tick = 0
            var blinkCounter = 0
            val random = java.util.Random()

            while (_state.value.isSpeaking) {
                tick++
                blinkCounter++

                // Eyeblink every ~45 ticks (approx 3.5 seconds)
                val shouldBlink = (blinkCounter % 45 in 0..2)

                // Head micro-movements (breathing + conversational emphasis)
                val headX = (kotlin.math.sin(tick * 0.08) * 1.5f).toFloat()
                val headY = (kotlin.math.cos(tick * 0.05) * 1.2f).toFloat()

                // Phoneme/viseme determination based on current active word and rhythmic frequency
                val word = _state.value.currentWord.lowercase()
                val (viseme, mouthOpen, widthFactor) = computeViseme(word, tick)

                // Simulated audio spectrum bars synchronized to mouth dynamics
                val baseEnergy = if (mouthOpen > 0.1f) mouthOpen else 0.08f
                val amps = List(16) { i ->
                    val variance = random.nextFloat() * 0.35f
                    (baseEnergy * (0.6f + variance) * (1f - (kotlin.math.abs(i - 8) * 0.05f))).coerceIn(0.05f, 1f)
                }

                _state.value = _state.value.copy(
                    mouthOpenAmount = mouthOpen,
                    mouthWidthFactor = widthFactor,
                    viseme = viseme,
                    headTiltX = headX,
                    headTiltY = headY,
                    isBlinking = shouldBlink,
                    audioAmplitudes = amps
                )

                onProgressUpdate?.invoke(_state.value.progress)
                delay(80) // ~12 fps viseme updates matching standard lip-sync keyframes
            }
        }
    }

    private fun computeViseme(word: String, tick: Int): Triple<VisemeShape, Float, Float> {
        if (word.isEmpty()) {
            return Triple(VisemeShape.CLOSED, 0f, 1.0f)
        }

        // Sub-cycle oscillation for syllables inside word
        val oscillation = (kotlin.math.sin(tick * 0.6) * 0.5f + 0.5f).toFloat()

        // Characterize word by prominent vowels / phonemes
        return when {
            word.contains("o") || word.contains("u") || word.contains("w") -> {
                val open = 0.45f + oscillation * 0.45f
                Triple(VisemeShape.ROUND_O, open, 0.85f)
            }
            word.contains("a") || word.contains("ah") -> {
                val open = 0.55f + oscillation * 0.45f
                Triple(VisemeShape.WIDE_OPEN, open, 1.15f)
            }
            word.contains("e") || word.contains("i") || word.contains("y") -> {
                val open = 0.35f + oscillation * 0.35f
                Triple(VisemeShape.WIDE_E, open, 1.25f)
            }
            word.startsWith("m") || word.startsWith("b") || word.startsWith("p") -> {
                if (tick % 3 == 0) {
                    Triple(VisemeShape.CLOSED, 0.05f, 1.0f)
                } else {
                    Triple(VisemeShape.SLIGHT_OPEN, 0.3f, 1.0f)
                }
            }
            word.contains("s") || word.contains("z") || word.contains("t") || word.contains("c") -> {
                val open = 0.25f + oscillation * 0.25f
                Triple(VisemeShape.TEETH_S, open, 1.05f)
            }
            else -> {
                val open = 0.3f + oscillation * 0.4f
                Triple(VisemeShape.SLIGHT_OPEN, open, 1.0f)
            }
        }
    }

    private fun stopAnimationLoop() {
        animationJob?.cancel()
        animationJob = null
    }

    fun release() {
        stop()
        tts?.shutdown()
        tts = null
    }
}

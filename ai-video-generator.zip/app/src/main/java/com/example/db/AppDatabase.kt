package com.example.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.model.AvatarModel
import com.example.model.VideoProject
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(entities = [VideoProject::class, AvatarModel::class], version = 1, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun videoDao(): VideoDao
    abstract fun avatarDao(): AvatarDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "ai_video_database"
                )
                    .addCallback(object : Callback() {
                        override fun onCreate(db: SupportSQLiteDatabase) {
                            super.onCreate(db)
                            // Prepopulate default sample avatars
                            CoroutineScope(Dispatchers.IO).launch {
                                INSTANCE?.avatarDao()?.insertAll(sampleAvatars)
                            }
                        }
                    })
                    .build()
                INSTANCE = instance
                instance
            }
        }

        val sampleAvatars = listOf(
            AvatarModel(
                id = "avatar_elena",
                name = "Elena",
                roleTitle = "Senior News & Media Anchor",
                drawableResName = "avatar_elena",
                isCustom = false,
                gender = "Female",
                personality = "Professional, Authoritative & Articulate",
                characteristics = "Refined studio lighting, crisp articulation, business attire"
            ),
            AvatarModel(
                id = "avatar_marcus",
                name = "Marcus",
                roleTitle = "Tech Educator & Keynote Speaker",
                drawableResName = "avatar_marcus",
                isCustom = false,
                gender = "Male",
                personality = "Friendly, Engaging & Enthusiastic",
                characteristics = "Modern navy blazer, warm smile, clear educational delivery"
            ),
            AvatarModel(
                id = "avatar_aria",
                name = "Aria",
                roleTitle = "Creative Host & Brand Ambassador",
                drawableResName = "avatar_aria",
                isCustom = false,
                gender = "Female",
                personality = "Dynamic, Creative & Inspiring",
                characteristics = "Vibrant style, approachable demeanor, lively expression"
            ),
            AvatarModel(
                id = "avatar_david",
                name = "David",
                roleTitle = "Executive Consultant & Strategist",
                drawableResName = "avatar_david",
                isCustom = false,
                gender = "Male",
                personality = "Calm, Strategic & Insightful",
                characteristics = "Executive suit, tailored glasses, measured confident pacing"
            )
        )
    }
}

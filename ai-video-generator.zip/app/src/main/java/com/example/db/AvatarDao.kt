package com.example.db

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.example.model.AvatarModel
import kotlinx.coroutines.flow.Flow

@Dao
interface AvatarDao {
    @Query("SELECT * FROM avatar_models ORDER BY isCustom ASC, name ASC")
    fun getAllAvatars(): Flow<List<AvatarModel>>

    @Query("SELECT * FROM avatar_models WHERE id = :id")
    suspend fun getAvatarById(id: String): AvatarModel?

    @Query("SELECT COUNT(*) FROM avatar_models")
    suspend fun getAvatarCount(): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAvatar(avatar: AvatarModel)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(avatars: List<AvatarModel>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAvatars(avatars: List<AvatarModel>)

    @Delete
    suspend fun deleteAvatar(avatar: AvatarModel)
}

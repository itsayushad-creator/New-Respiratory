package com.example.db

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.model.VideoProject
import kotlinx.coroutines.flow.Flow

@Dao
interface VideoDao {
    @Query("SELECT * FROM video_projects ORDER BY timestamp DESC")
    fun getAllVideos(): Flow<List<VideoProject>>

    @Query("SELECT * FROM video_projects WHERE id = :id")
    suspend fun getVideoById(id: Long): VideoProject?

    @Query("SELECT * FROM video_projects WHERE type = :type ORDER BY timestamp DESC")
    fun getVideosByType(type: String): Flow<List<VideoProject>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertVideo(video: VideoProject): Long

    @Update
    suspend fun updateVideo(video: VideoProject)

    @Delete
    suspend fun deleteVideo(video: VideoProject)

    @Query("DELETE FROM video_projects WHERE id = :id")
    suspend fun deleteVideoById(id: Long)
}

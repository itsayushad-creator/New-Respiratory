package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.lifecycleScope
import com.example.audio.LipSyncEngine
import com.example.db.AppDatabase
import com.example.ui.avatar.AvatarStudioScreen
import com.example.ui.explainer.MakeExplainerScreen
import com.example.ui.library.LibraryScreen
import com.example.ui.theme.DarkBackground
import com.example.ui.theme.DarkBorder
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.theme.StudioCyan
import com.example.ui.theme.StudioViolet
import com.example.ui.videogen.VideoGenScreen
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

enum class MainDestination(
    val title: String,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector,
    val badge: String? = null
) {
    VIDEO_GEN("Video Gen", Icons.Filled.MovieCreation, Icons.Outlined.MovieCreation, null),
    EXPLAINER("Explainer", Icons.Filled.AutoAwesome, Icons.Outlined.AutoAwesome, "Bonus"),
    AVATAR("Avatars", Icons.Filled.Face, Icons.Outlined.Face, "Lip-Sync"),
    LIBRARY("Library", Icons.Filled.VideoLibrary, Icons.Outlined.VideoLibrary, null)
}

class MainActivity : ComponentActivity() {

    private lateinit var database: AppDatabase
    private lateinit var lipSyncEngine: LipSyncEngine

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        database = AppDatabase.getDatabase(applicationContext)
        lipSyncEngine = LipSyncEngine(applicationContext)

        // Ensure default sample avatars exist in database
        lifecycleScope.launch(Dispatchers.IO) {
            val count = database.avatarDao().getAvatarCount()
            if (count == 0) {
                database.avatarDao().insertAvatars(AppDatabase.sampleAvatars)
            }
        }

        setContent {
            MyApplicationTheme {
                MainAppContent(
                    database = database,
                    lipSyncEngine = lipSyncEngine
                )
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        lipSyncEngine.stop()
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainAppContent(
    database: AppDatabase,
    lipSyncEngine: LipSyncEngine
) {
    var currentDestination by remember { mutableStateOf(MainDestination.VIDEO_GEN) }

    Scaffold(
        modifier = Modifier
            .fillMaxSize()
            .background(DarkBackground),
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(34.dp)
                                .clip(RoundedCornerShape(10.dp))
                                .background(
                                    Brush.linearGradient(
                                        colors = listOf(StudioViolet, StudioCyan)
                                    )
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                Icons.Default.PlayArrow,
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = "AI Video Generator",
                                    fontSize = 17.sp,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = Color.White
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(4.dp))
                                        .background(StudioCyan.copy(alpha = 0.2f))
                                        .padding(horizontal = 5.dp, vertical = 2.dp)
                                ) {
                                    Text(
                                        text = "PRO",
                                        fontSize = 9.sp,
                                        fontWeight = FontWeight.ExtraBold,
                                        color = StudioCyan
                                    )
                                }
                            }
                            Text(
                                text = "Cinematic • Explainers • Talking Avatars",
                                fontSize = 10.sp,
                                color = Color(0xFFA4B0BE)
                            )
                        }
                    }
                },
                actions = {
                    IconButton(
                        onClick = { currentDestination = MainDestination.LIBRARY },
                        modifier = Modifier.testTag("top_library_btn")
                    ) {
                        Icon(
                            Icons.Default.VideoLibrary,
                            contentDescription = "Saved Videos",
                            tint = if (currentDestination == MainDestination.LIBRARY) StudioCyan else Color.White
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color(0xFF0D0F18),
                    titleContentColor = Color.White
                )
            )
        },
        bottomBar = {
            NavigationBar(
                containerColor = Color(0xFF0D0F18),
                contentColor = Color.White,
                tonalElevation = 8.dp,
                modifier = Modifier.border(BorderStroke(1.dp, DarkBorder))
            ) {
                MainDestination.values().forEach { destination ->
                    val isSelected = currentDestination == destination

                    NavigationBarItem(
                        selected = isSelected,
                        onClick = { currentDestination = destination },
                        icon = {
                            BadgedBox(
                                badge = {
                                    destination.badge?.let { badgeText ->
                                        Badge(
                                            containerColor = if (badgeText == "Bonus") StudioCyan else StudioViolet,
                                            contentColor = Color.Black
                                        ) {
                                            Text(badgeText, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                                        }
                                    }
                                }
                            ) {
                                Icon(
                                    imageVector = if (isSelected) destination.selectedIcon else destination.unselectedIcon,
                                    contentDescription = destination.title,
                                    tint = if (isSelected) StudioCyan else Color(0xFF718096)
                                )
                            }
                        },
                        label = {
                            Text(
                                text = destination.title,
                                fontSize = 11.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                color = if (isSelected) StudioCyan else Color(0xFF718096)
                            )
                        },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = StudioCyan,
                            unselectedIconColor = Color(0xFF718096),
                            indicatorColor = Color(0xFF192036)
                        ),
                        modifier = Modifier.testTag("nav_tab_${destination.name.lowercase()}")
                    )
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (currentDestination) {
                MainDestination.VIDEO_GEN -> {
                    VideoGenScreen(
                        database = database,
                        modifier = Modifier.fillMaxSize()
                    )
                }
                MainDestination.EXPLAINER -> {
                    MakeExplainerScreen(
                        database = database,
                        lipSyncEngine = lipSyncEngine,
                        modifier = Modifier.fillMaxSize()
                    )
                }
                MainDestination.AVATAR -> {
                    AvatarStudioScreen(
                        database = database,
                        lipSyncEngine = lipSyncEngine,
                        modifier = Modifier.fillMaxSize()
                    )
                }
                MainDestination.LIBRARY -> {
                    LibraryScreen(
                        database = database,
                        lipSyncEngine = lipSyncEngine,
                        modifier = Modifier.fillMaxSize()
                    )
                }
            }
        }
    }
}

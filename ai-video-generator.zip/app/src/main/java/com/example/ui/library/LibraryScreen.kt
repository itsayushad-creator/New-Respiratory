package com.example.ui.library

import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.audio.LipSyncEngine
import com.example.db.AppDatabase
import com.example.model.AvatarModel
import com.example.model.VideoProject
import com.example.model.VideoType
import com.example.ui.avatar.AvatarVideoPlayer
import com.example.ui.explainer.ExplainerVideoPlayer
import com.example.ui.videogen.VideoPlayerView
import com.example.util.VideoExporter
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun LibraryScreen(
    database: AppDatabase,
    lipSyncEngine: LipSyncEngine,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    val allVideos by database.videoDao().getAllVideos().collectAsState(initial = emptyList())
    val allAvatars by database.avatarDao().getAllAvatars().collectAsState(initial = emptyList())

    var selectedFilter by remember { mutableStateOf("All") }
    var selectedVideoForPlayback by remember { mutableStateOf<VideoProject?>(null) }

    val filterOptions = listOf("All", "Explainer", "Avatar", "Text/Image")

    val filteredVideos = remember(allVideos, selectedFilter) {
        when (selectedFilter) {
            "Explainer" -> allVideos.filter { it.type == VideoType.EXPLAINER.name }
            "Avatar" -> allVideos.filter { it.type == VideoType.AVATAR.name }
            "Text/Image" -> allVideos.filter { it.type == VideoType.TEXT_TO_VIDEO.name || it.type == VideoType.IMAGE_TO_VIDEO.name }
            else -> allVideos
        }
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFF0A0C14))
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 12.dp, bottom = 40.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Library Header
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "Video Projects Library",
                        style = MaterialTheme.typography.titleLarge.copy(
                            color = Color.White,
                            fontWeight = FontWeight.ExtraBold
                        )
                    )
                    Text(
                        text = "${allVideos.size} videos created with AI",
                        style = MaterialTheme.typography.bodySmall.copy(color = Color(0xFFA4B0BE))
                    )
                }

                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = Color(0xFF1E2235)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.VideoLibrary, contentDescription = null, tint = Color(0xFF00D2D3), modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Exported Ready", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color.White)
                    }
                }
            }
        }

        // Active Full Player View if a video is tapped
        if (selectedVideoForPlayback != null) {
            item {
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = Color(0xFF131728),
                    border = BorderStroke(1.dp, Color(0xFF00D2D3)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "PLAYING PROJECT",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    color = Color(0xFF00D2D3),
                                    fontWeight = FontWeight.Bold,
                                    letterSpacing = 1.sp
                                )
                            )
                            IconButton(
                                onClick = { selectedVideoForPlayback = null },
                                modifier = Modifier.size(28.dp)
                            ) {
                                Icon(Icons.Default.Close, contentDescription = "Close Player", tint = Color.White)
                            }
                        }

                        val activeProj = selectedVideoForPlayback!!
                        when (activeProj.type) {
                            VideoType.AVATAR.name -> {
                                val av = allAvatars.find { it.id == activeProj.avatarId }
                                    ?: AppDatabase.sampleAvatars.find { it.id == activeProj.avatarId }
                                    ?: AppDatabase.sampleAvatars.first()
                                AvatarVideoPlayer(
                                    project = activeProj,
                                    avatar = av,
                                    lipSyncEngine = lipSyncEngine,
                                    onDownloadClick = {
                                        scope.launch { VideoExporter.downloadVideoProject(context, activeProj, {}, {}) }
                                    },
                                    onShareClick = { VideoExporter.shareVideoProject(context, activeProj) }
                                )
                            }
                            VideoType.EXPLAINER.name -> {
                                ExplainerVideoPlayer(
                                    project = activeProj,
                                    lipSyncEngine = lipSyncEngine,
                                    onDownloadClick = {
                                        scope.launch { VideoExporter.downloadVideoProject(context, activeProj, {}, {}) }
                                    },
                                    onShareClick = { VideoExporter.shareVideoProject(context, activeProj) }
                                )
                            }
                            else -> {
                                VideoPlayerView(
                                    project = activeProj,
                                    onDownloadClick = {
                                        scope.launch { VideoExporter.downloadVideoProject(context, activeProj, {}, {}) }
                                    },
                                    onShareClick = { VideoExporter.shareVideoProject(context, activeProj) }
                                )
                            }
                        }
                    }
                }
            }
        }

        // Filter Pills
        item {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(filterOptions) { opt ->
                    val isSelected = selectedFilter == opt
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = if (isSelected) Color(0xFF7C5CFC) else Color(0xFF141726),
                        border = BorderStroke(1.dp, if (isSelected) Color(0xFF9E86FD) else Color(0xFF262B40)),
                        modifier = Modifier.clickable { selectedFilter = opt }
                    ) {
                        Text(
                            text = opt,
                            fontSize = 12.sp,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                            color = if (isSelected) Color.White else Color(0xFFA4B0BE),
                            modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp)
                        )
                    }
                }
            }
        }

        // Video Items List
        if (filteredVideos.isEmpty()) {
            item {
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = Color(0xFF141726),
                    border = BorderStroke(1.dp, Color(0xFF262B40)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(32.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(
                            Icons.Default.VideoCameraBack,
                            contentDescription = null,
                            tint = Color(0xFF7C5CFC),
                            modifier = Modifier.size(48.dp)
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "No Videos Yet",
                            style = MaterialTheme.typography.titleMedium.copy(
                                color = Color.White,
                                fontWeight = FontWeight.Bold
                            )
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Generate a Text/Image video, Explainer video, or Avatar video above to start building your library.",
                            style = MaterialTheme.typography.bodySmall.copy(color = Color(0xFFA4B0BE)),
                            textAlign = androidx.compose.ui.text.style.TextAlign.Center
                        )
                    }
                }
            }
        } else {
            items(filteredVideos, key = { it.id }) { video ->
                VideoProjectCard(
                    project = video,
                    onPlayClick = { selectedVideoForPlayback = video },
                    onDownloadClick = {
                        scope.launch {
                            VideoExporter.downloadVideoProject(context, video, {}, {})
                        }
                    },
                    onShareClick = {
                        VideoExporter.shareVideoProject(context, video)
                    },
                    onDeleteClick = {
                        scope.launch {
                            database.videoDao().deleteVideo(video)
                            if (selectedVideoForPlayback?.id == video.id) {
                                selectedVideoForPlayback = null
                            }
                            Toast.makeText(context, "Deleted from library", Toast.LENGTH_SHORT).show()
                        }
                    }
                )
            }
        }
    }
}

@Composable
fun VideoProjectCard(
    project: VideoProject,
    onPlayClick: () -> Unit,
    onDownloadClick: () -> Unit,
    onShareClick: () -> Unit,
    onDeleteClick: () -> Unit
) {
    val dateStr = remember(project.timestamp) {
        SimpleDateFormat("MMM dd, yyyy", Locale.getDefault()).format(Date(project.timestamp))
    }

    val typeBadgeColor = when (project.type) {
        VideoType.EXPLAINER.name -> Color(0xFF00D2D3)
        VideoType.AVATAR.name -> Color(0xFF7C5CFC)
        VideoType.IMAGE_TO_VIDEO.name -> Color(0xFFFF7675)
        else -> Color(0xFF54A0FF)
    }

    Surface(
        shape = RoundedCornerShape(16.dp),
        color = Color(0xFF141726),
        border = BorderStroke(1.dp, Color(0xFF262B40)),
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onPlayClick() }
            .testTag("project_card_${project.id}")
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Type Badge
                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = typeBadgeColor.copy(alpha = 0.2f)
                ) {
                    Text(
                        text = project.type.replace("_", " "),
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = typeBadgeColor,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                    )
                }

                Text(
                    text = dateStr,
                    fontSize = 11.sp,
                    color = Color(0xFF718096)
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = project.title,
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White,
                maxLines = 1
            )

            Spacer(modifier = Modifier.height(4.dp))

            Text(
                text = "\"${project.promptOrScript}\"",
                fontSize = 12.sp,
                color = Color(0xFFA4B0BE),
                maxLines = 2
            )

            Spacer(modifier = Modifier.height(10.dp))

            // Metadata Chips Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = Color(0xFF1E2235)
                ) {
                    Text(
                        text = "${project.durationSeconds}s",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = Color.White,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }
                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = Color(0xFF1E2235)
                ) {
                    Text(
                        text = project.aspectRatio,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = Color.White,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }
                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = Color(0xFF1E2235)
                ) {
                    Text(
                        text = project.style,
                        fontSize = 10.sp,
                        color = Color(0xFFCBD5E1),
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }
                if (project.avatarName != null) {
                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = Color(0xFF7C5CFC).copy(alpha = 0.2f)
                    ) {
                        Text(
                            text = project.avatarName,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF9E86FD),
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.weight(1f))

                // Action buttons
                IconButton(
                    onClick = onShareClick,
                    modifier = Modifier.size(32.dp)
                ) {
                    Icon(Icons.Default.Share, contentDescription = "Share", tint = Color(0xFFA4B0BE), modifier = Modifier.size(16.dp))
                }

                IconButton(
                    onClick = onDownloadClick,
                    modifier = Modifier.size(32.dp).testTag("card_download_btn")
                ) {
                    Icon(Icons.Default.Download, contentDescription = "Download", tint = Color(0xFF00D2D3), modifier = Modifier.size(18.dp))
                }

                IconButton(
                    onClick = onDeleteClick,
                    modifier = Modifier.size(32.dp)
                ) {
                    Icon(Icons.Default.DeleteOutline, contentDescription = "Delete", tint = Color(0xFFFF7675), modifier = Modifier.size(16.dp))
                }
            }
        }
    }
}

package com.example.ui.videogen

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.rememberAsyncImagePainter
import com.example.R
import com.example.model.VideoProject
import kotlinx.coroutines.delay
import java.io.File

@Composable
fun VideoPlayerView(
    project: VideoProject,
    onDownloadClick: () -> Unit,
    onShareClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    var isPlaying by remember { mutableStateOf(true) }
    var isLooping by remember { mutableStateOf(true) }
    var progressSeconds by remember { mutableFloatStateOf(0f) }

    val totalDuration = project.durationSeconds.toFloat().coerceAtLeast(5f)

    // Playback loop ticker
    LaunchedEffect(isPlaying, isLooping) {
        while (isPlaying) {
            delay(100)
            progressSeconds += 0.1f
            if (progressSeconds >= totalDuration) {
                if (isLooping) {
                    progressSeconds = 0f
                } else {
                    isPlaying = false
                }
            }
        }
    }

    // Dynamic Camera Motion Animation
    val infiniteTransition = rememberInfiniteTransition(label = "camera_motion")
    val cameraZoom by infiniteTransition.animateFloat(
        initialValue = 1.0f,
        targetValue = 1.15f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = (totalDuration * 500).toInt(), easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "zoom"
    )

    val cameraPanX by infiniteTransition.animateFloat(
        initialValue = -12f,
        targetValue = 12f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = (totalDuration * 700).toInt(), easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "panX"
    )

    val lightSweep by infiniteTransition.animateFloat(
        initialValue = -200f,
        targetValue = 800f,
        animationSpec = infiniteRepeatable(
            animation = tween(4000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "lightSweep"
    )

    val aspectMultiplier = when (project.aspectRatio) {
        "9:16" -> 9f / 16f
        "1:1" -> 1f / 1f
        "4:3" -> 4f / 3f
        else -> 16f / 9f
    }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .background(Color(0xFF11131E))
            .border(1.dp, Color(0xFF262B40), RoundedCornerShape(20.dp))
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Video Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(10.dp)
                        .clip(CircleShape)
                        .background(if (isPlaying) Color(0xFF00D2D3) else Color(0xFFFF9F43))
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "${project.type.replace("_", " ")} • ${project.style.uppercase()}",
                    style = MaterialTheme.typography.labelSmall.copy(
                        color = Color(0xFF00D2D3),
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.1.sp
                    )
                )
            }

            Row {
                IconButton(
                    onClick = onShareClick,
                    modifier = Modifier.size(36.dp).testTag("video_share_btn")
                ) {
                    Icon(Icons.Default.Share, contentDescription = "Share", tint = Color.White)
                }
                Spacer(modifier = Modifier.width(4.dp))
                FilledTonalButton(
                    onClick = onDownloadClick,
                    modifier = Modifier.height(36.dp).testTag("video_download_btn"),
                    colors = ButtonDefaults.filledTonalButtonColors(
                        containerColor = Color(0xFF7C5CFC),
                        contentColor = Color.White
                    ),
                    contentPadding = PaddingValues(horizontal = 12.dp)
                ) {
                    Icon(Icons.Default.Download, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Download", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Video Viewport Canvas
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .heightIn(min = 260.dp, max = 360.dp)
                .aspectRatio(aspectMultiplier.coerceIn(0.7f, 1.8f))
                .clip(RoundedCornerShape(16.dp))
                .background(Color.Black)
                .border(1.dp, Color(0xFF333852), RoundedCornerShape(16.dp)),
            contentAlignment = Alignment.Center
        ) {
            // Video Frame Content with Motion Layer
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .graphicsLayer {
                        if (isPlaying) {
                            scaleX = cameraZoom
                            scaleY = cameraZoom
                            translationX = cameraPanX
                        }
                    }
            ) {
                // Source Image if available (from Image-to-Video or generated thumbnail)
                if (!project.sourceImageUri.isNullOrBlank()) {
                    val file = File(project.sourceImageUri)
                    val model = if (file.exists()) file else project.sourceImageUri
                    Image(
                        painter = rememberAsyncImagePainter(model = model),
                        contentDescription = "Generated Video Frame",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                } else {
                    // Procedural Cinematic Visual Canvas based on Style
                    ProceduralVideoCanvas(style = project.style, modifier = Modifier.fillMaxSize())
                }

                // Cinematic Light Sweep / Film Flare
                Canvas(modifier = Modifier.fillMaxSize()) {
                    if (isPlaying) {
                        drawRect(
                            brush = Brush.linearGradient(
                                colors = listOf(
                                    Color.Transparent,
                                    Color.White.copy(alpha = 0.08f),
                                    Color(0xFF00D2D3).copy(alpha = 0.12f),
                                    Color.Transparent
                                ),
                                start = Offset(lightSweep, 0f),
                                end = Offset(lightSweep + 180f, size.height)
                            )
                        )
                    }
                }
            }

            // Top Badges Overlay
            Row(
                modifier = Modifier
                    .align(Alignment.TopStart)
                    .padding(12.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = Color.Black.copy(alpha = 0.7f)
                ) {
                    Text(
                        text = "4K • 60 FPS",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF00D2D3),
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                    )
                }
                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = Color.Black.copy(alpha = 0.7f)
                ) {
                    Text(
                        text = project.aspectRatio,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                    )
                }
            }

            // Timecode Overlay Top-Right
            Surface(
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(12.dp),
                shape = RoundedCornerShape(6.dp),
                color = Color.Black.copy(alpha = 0.7f)
            ) {
                val curMin = (progressSeconds.toInt() / 60)
                val curSec = (progressSeconds.toInt() % 60)
                val totMin = (totalDuration.toInt() / 60)
                val totSec = (totalDuration.toInt() % 60)
                Text(
                    text = String.format("%02d:%02d / %02d:%02d", curMin, curSec, totMin, totSec),
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    color = Color.White,
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                )
            }

            // Bottom Prompt Preview Bar
            Surface(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth()
                    .padding(10.dp),
                shape = RoundedCornerShape(8.dp),
                color = Color.Black.copy(alpha = 0.75f)
            ) {
                Text(
                    text = "\"${project.promptOrScript}\"",
                    fontSize = 11.sp,
                    color = Color(0xFFE2E8F0),
                    maxLines = 2,
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                )
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Progress Slider
        val currentProgress = (progressSeconds / totalDuration).coerceIn(0f, 1f)
        Slider(
            value = currentProgress,
            onValueChange = { frac ->
                progressSeconds = frac * totalDuration
            },
            modifier = Modifier.fillMaxWidth().testTag("video_progress_slider"),
            colors = SliderDefaults.colors(
                thumbColor = Color(0xFF00D2D3),
                activeTrackColor = Color(0xFF7C5CFC),
                inactiveTrackColor = Color(0xFF262B40)
            )
        )

        // Bottom Controls
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Loop toggle
            IconButton(
                onClick = { isLooping = !isLooping },
                modifier = Modifier.testTag("video_loop_btn")
            ) {
                Icon(
                    Icons.Default.Repeat,
                    contentDescription = "Toggle Loop",
                    tint = if (isLooping) Color(0xFF00D2D3) else Color(0xFF718096)
                )
            }

            // Center Play / Pause
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(
                    onClick = { progressSeconds = 0f; isPlaying = true },
                    modifier = Modifier.size(42.dp)
                ) {
                    Icon(Icons.Default.Replay, contentDescription = "Restart", tint = Color.White)
                }

                Spacer(modifier = Modifier.width(8.dp))

                FloatingActionButton(
                    onClick = { isPlaying = !isPlaying },
                    containerColor = Color(0xFF7C5CFC),
                    contentColor = Color.White,
                    modifier = Modifier.size(52.dp).testTag("video_play_pause_btn")
                ) {
                    Icon(
                        imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                        contentDescription = if (isPlaying) "Play" else "Pause",
                        modifier = Modifier.size(28.dp)
                    )
                }
            }

            // Duration tag
            Surface(
                shape = RoundedCornerShape(8.dp),
                color = Color(0xFF23273A)
            ) {
                Text(
                    text = "${project.durationSeconds}s Clip",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = Color(0xFFA4B0BE),
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp)
                )
            }
        }
    }
}

@Composable
fun ProceduralVideoCanvas(style: String, modifier: Modifier = Modifier) {
    val infiniteTransition = rememberInfiniteTransition(label = "particle_motion")
    val phase by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(6000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "phase"
    )

    Canvas(modifier = modifier) {
        val cx = size.width / 2f
        val cy = size.height / 2f

        when (style.lowercase()) {
            "cyberpunk" -> {
                // Neon grid & cyan/magenta haze
                drawRect(
                    brush = Brush.verticalGradient(
                        colors = listOf(Color(0xFF0F051D), Color(0xFF1E0B36), Color(0xFF030008))
                    )
                )
                // Horizon perspective lines
                for (i in -4..4) {
                    drawLine(
                        color = Color(0xFF00D2D3).copy(alpha = 0.35f),
                        start = Offset(cx, cy * 0.7f),
                        end = Offset(cx + i * (size.width * 0.22f), size.height),
                        strokeWidth = 2f
                    )
                }
                // Neon sun
                drawCircle(
                    brush = Brush.verticalGradient(listOf(Color(0xFFFF007F), Color(0xFFFFD60A))),
                    center = Offset(cx, cy * 0.7f),
                    radius = 45f
                )
            }
            "anime", "anime/manga" -> {
                // Vibrant anime sky & clouds
                drawRect(
                    brush = Brush.verticalGradient(
                        colors = listOf(Color(0xFF4A90E2), Color(0xFFE88A9A), Color(0xFFFDEB71))
                    )
                )
                // Light rays
                drawCircle(
                    color = Color.White.copy(alpha = 0.3f),
                    center = Offset(cx * 1.2f, cy * 0.6f),
                    radius = 80f
                )
            }
            "3d render", "3d animation" -> {
                // Sleek metallic 3D sphere with ambient shadow
                drawRect(
                    brush = Brush.radialGradient(
                        colors = listOf(Color(0xFF2E3856), Color(0xFF101424))
                    )
                )
                drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf(Color(0xFF00D2D3), Color(0xFF7C5CFC), Color(0xFF1A1D2E)),
                        center = Offset(cx - 20f, cy - 20f),
                        radius = 80f
                    ),
                    center = Offset(cx, cy),
                    radius = 70f
                )
            }
            else -> {
                // Cinematic & Realistic 4K: Dark atmospheric mood
                drawRect(
                    brush = Brush.radialGradient(
                        colors = listOf(Color(0xFF22293F), Color(0xFF0D0F18), Color(0xFF05060A))
                    )
                )
                // Bokeh particles
                for (p in 0..12) {
                    val px = (cx + (kotlin.math.sin(p.toDouble() * 1.5 + phase * 6.28) * size.width * 0.38f)).toFloat()
                    val py = (cy + (kotlin.math.cos(p.toDouble() * 1.2 + phase * 6.28) * size.height * 0.35f)).toFloat()
                    drawCircle(
                        color = if (p % 2 == 0) Color(0xFF00D2D3).copy(alpha = 0.4f) else Color(0xFFFF7675).copy(alpha = 0.3f),
                        center = Offset(px, py),
                        radius = (8f + (p % 6) * 3f)
                    )
                }
            }
        }
    }
}

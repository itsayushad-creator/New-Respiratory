package com.example.ui.explainer

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.audio.LipSyncEngine
import com.example.model.ExplainerScene
import com.example.model.VideoProject
import kotlinx.coroutines.delay
import org.json.JSONArray
import org.json.JSONObject

@Composable
fun ExplainerVideoPlayer(
    project: VideoProject,
    lipSyncEngine: LipSyncEngine,
    onDownloadClick: () -> Unit,
    onShareClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    // Parse scenes from json or generate defaults
    val scenes = remember(project.explainerDataJson) {
        parseScenes(project.explainerDataJson, project.explainerTopic ?: project.title)
    }

    var currentSceneIndex by remember { mutableIntStateOf(0) }
    var isPlaying by remember { mutableStateOf(true) }
    var sceneElapsedSeconds by remember { mutableFloatStateOf(0f) }

    val currentScene = scenes.getOrElse(currentSceneIndex) { scenes.first() }

    // Configure audio & trigger narration on scene change
    LaunchedEffect(currentSceneIndex, isPlaying) {
        if (isPlaying && currentSceneIndex < scenes.size) {
            lipSyncEngine.setLanguage(project.language)
            lipSyncEngine.setVoiceGender(project.voiceGender)
            lipSyncEngine.speak(currentScene.narration)
        } else {
            lipSyncEngine.pause()
        }
    }

    // Auto-advance scenes based on duration
    LaunchedEffect(currentSceneIndex, isPlaying) {
        sceneElapsedSeconds = 0f
        val sceneDuration = currentScene.durationSeconds.toFloat().coerceAtLeast(6f)
        while (isPlaying && sceneElapsedSeconds < sceneDuration) {
            delay(100)
            sceneElapsedSeconds += 0.1f
        }
        if (isPlaying) {
            if (currentSceneIndex < scenes.size - 1) {
                currentSceneIndex++
            } else {
                isPlaying = false // Finished playing all scenes
            }
        }
    }

    DisposableEffect(Unit) {
        onDispose {
            lipSyncEngine.stop()
        }
    }

    // Aspect ratio container calculation
    val aspectMultiplier = when (project.aspectRatio) {
        "9:16" -> 9f / 16f
        "1:1" -> 1f / 1f
        else -> 16f / 9f
    }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .background(Color(0xFF10121C))
            .border(1.dp, Color(0xFF2B3047), RoundedCornerShape(20.dp))
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Explainer Video Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .clip(CircleShape)
                            .background(if (isPlaying) Color(0xFF00D2D3) else Color(0xFFFF9F43))
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "EXPLAINER ANIMATION • ${project.animationStyle.uppercase()}",
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = Color(0xFF00D2D3),
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.sp
                        )
                    )
                }
                Text(
                    text = project.explainerTopic ?: project.title,
                    style = MaterialTheme.typography.titleMedium.copy(
                        color = Color.White,
                        fontWeight = FontWeight.Bold
                    ),
                    maxLines = 1
                )
            }

            Row {
                IconButton(
                    onClick = onShareClick,
                    modifier = Modifier.size(36.dp).testTag("explainer_share_btn")
                ) {
                    Icon(Icons.Default.Share, contentDescription = "Share", tint = Color.White)
                }
                Spacer(modifier = Modifier.width(4.dp))
                FilledTonalButton(
                    onClick = onDownloadClick,
                    modifier = Modifier.height(36.dp).testTag("explainer_download_btn"),
                    colors = ButtonDefaults.filledTonalButtonColors(
                        containerColor = Color(0xFF00D2D3),
                        contentColor = Color(0xFF0D0E15)
                    ),
                    contentPadding = PaddingValues(horizontal = 12.dp)
                ) {
                    Icon(Icons.Default.Download, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Download", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Animated Screen Frame Container
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .heightIn(min = 280.dp, max = 380.dp)
                .aspectRatio(aspectMultiplier.coerceIn(0.7f, 1.8f))
                .clip(RoundedCornerShape(16.dp))
                .background(getCanvasBackground(project.animationStyle))
                .border(1.dp, Color(0xFF333852), RoundedCornerShape(16.dp)),
            contentAlignment = Alignment.Center
        ) {
            // Scene Animation Renderer
            AnimatedContent(
                targetState = currentScene,
                transitionSpec = {
                    (fadeIn(animationSpec = tween(500)) + scaleIn(initialScale = 0.92f))
                        .togetherWith(fadeOut(animationSpec = tween(400)) + scaleOut(targetScale = 1.05f))
                },
                label = "scene_anim"
            ) { scene ->
                SceneCanvasView(
                    scene = scene,
                    animationStyle = project.animationStyle,
                    sceneElapsedSeconds = sceneElapsedSeconds,
                    modifier = Modifier.fillMaxSize()
                )
            }

            // Top Overlay: Scene Progress Indicators
            Row(
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .fillMaxWidth()
                    .padding(12.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                scenes.forEachIndexed { idx, s ->
                    val isDone = idx < currentSceneIndex
                    val isCurrent = idx == currentSceneIndex
                    val progressFraction = if (isDone) 1f else if (isCurrent) (sceneElapsedSeconds / s.durationSeconds.toFloat()).coerceIn(0f, 1f) else 0f

                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .height(4.dp)
                            .clip(RoundedCornerShape(2.dp))
                            .background(Color.White.copy(alpha = 0.2f))
                            .clickable {
                                currentSceneIndex = idx
                                isPlaying = true
                            }
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxHeight()
                                .fillMaxWidth(progressFraction)
                                .background(Color(0xFF00D2D3))
                        )
                    }
                }
            }

            // Bottom Subtitle Ribbon (Subtitles: On/Off)
            if (project.subtitleStyle != "Off") {
                Box(
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 12.dp)
                ) {
                    SubtitleBanner(
                        text = currentScene.narration,
                        style = project.subtitleStyle
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Scene Navigation Tabs & Controls
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Prev Scene Button
            IconButton(
                onClick = {
                    if (currentSceneIndex > 0) {
                        currentSceneIndex--
                        isPlaying = true
                    }
                },
                enabled = currentSceneIndex > 0,
                modifier = Modifier.testTag("explainer_prev_btn")
            ) {
                Icon(Icons.Default.SkipPrevious, contentDescription = "Prev Scene", tint = if (currentSceneIndex > 0) Color.White else Color(0xFF4A4E69))
            }

            // Center Play / Pause
            FloatingActionButton(
                onClick = {
                    isPlaying = !isPlaying
                },
                containerColor = Color(0xFF00D2D3),
                contentColor = Color(0xFF0D0E15),
                modifier = Modifier.size(50.dp).testTag("explainer_play_pause_btn")
            ) {
                Icon(
                    imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                    contentDescription = if (isPlaying) "Play" else "Pause",
                    modifier = Modifier.size(26.dp)
                )
            }

            // Next Scene Button
            IconButton(
                onClick = {
                    if (currentSceneIndex < scenes.size - 1) {
                        currentSceneIndex++
                        isPlaying = true
                    } else {
                        currentSceneIndex = 0
                        isPlaying = true
                    }
                },
                modifier = Modifier.testTag("explainer_next_btn")
            ) {
                Icon(Icons.Default.SkipNext, contentDescription = "Next Scene", tint = Color.White)
            }
        }

        Spacer(modifier = Modifier.height(6.dp))

        // Scene Indicators Summary
        Text(
            text = "Scene ${currentSceneIndex + 1} of ${scenes.size} • ${project.language} (${project.voiceGender})",
            style = MaterialTheme.typography.bodySmall.copy(color = Color(0xFFA4B0BE))
        )
    }
}

@Composable
fun SceneCanvasView(
    scene: ExplainerScene,
    animationStyle: String,
    sceneElapsedSeconds: Float,
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "canvas_anim")
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 0.95f,
        targetValue = 1.05f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse"
    )

    val rotationDegree by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(20000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "rotate"
    )

    Box(
        modifier = modifier.padding(16.dp),
        contentAlignment = Alignment.Center
    ) {
        // Graphic visuals based on animation style
        Canvas(modifier = Modifier.fillMaxSize()) {
            val cx = size.width / 2f
            val cy = size.height * 0.38f

            when (animationStyle.lowercase()) {
                "whiteboard", "whiteboard doodle" -> {
                    // Whiteboard sketch grid + dashed lines
                    drawRoundRect(
                        color = Color(0xFF333333).copy(alpha = 0.4f),
                        topLeft = Offset(cx - 70f, cy - 70f),
                        size = Size(140f, 140f),
                        cornerRadius = CornerRadius(16f, 16f),
                        style = Stroke(width = 3f)
                    )
                    // Doodle atom / orbital rings
                    drawCircle(
                        color = Color(0xFF00D2D3),
                        center = Offset(cx, cy),
                        radius = 45f * pulseScale,
                        style = Stroke(width = 2.5f)
                    )
                    drawCircle(
                        color = Color(0xFF7C5CFC),
                        center = Offset(cx, cy),
                        radius = 20f
                    )
                }
                "isometric 3d" -> {
                    // Isometric diamond grid
                    val diamondPath = Path().apply {
                        moveTo(cx, cy - 60f)
                        lineTo(cx + 80f, cy)
                        lineTo(cx, cy + 60f)
                        lineTo(cx - 80f, cy)
                        close()
                    }
                    drawPath(
                        path = diamondPath,
                        brush = Brush.verticalGradient(listOf(Color(0xFF7C5CFC), Color(0xFF00D2D3))),
                        style = Stroke(width = 3.5f)
                    )
                    drawCircle(
                        color = Color(0xFFFF7675),
                        center = Offset(cx, cy),
                        radius = 16f * pulseScale
                    )
                }
                "minimalist line art" -> {
                    // Clean minimal geometric lines
                    drawLine(
                        color = Color.White.copy(alpha = 0.7f),
                        start = Offset(cx - 90f, cy),
                        end = Offset(cx + 90f, cy),
                        strokeWidth = 2f
                    )
                    drawCircle(
                        color = Color.White,
                        center = Offset(cx, cy),
                        radius = 40f,
                        style = Stroke(width = 2f)
                    )
                    drawCircle(
                        color = Color(0xFF00D2D3),
                        center = Offset(cx, cy),
                        radius = 12f
                    )
                }
                else -> {
                    // Modern Motion Graphics
                    drawCircle(
                        brush = Brush.sweepGradient(
                            listOf(Color(0xFF7C5CFC), Color(0xFF00D2D3), Color(0xFFFF7675), Color(0xFF7C5CFC))
                        ),
                        center = Offset(cx, cy),
                        radius = 55f * pulseScale,
                        style = Stroke(width = 4f)
                    )
                    drawCircle(
                        color = Color(0xFF00D2D3).copy(alpha = 0.2f),
                        center = Offset(cx, cy),
                        radius = 75f
                    )
                }
            }
        }

        // Scene Content Card (Title + Points)
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 110.dp, bottom = 48.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            // Scene Title
            Surface(
                shape = RoundedCornerShape(20.dp),
                color = Color.Black.copy(alpha = 0.5f),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color.White.copy(alpha = 0.15f))
            ) {
                Text(
                    text = scene.title,
                    fontSize = 17.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = Color.White,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp)
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Key Points (bullet items animated)
            Column(
                verticalArrangement = Arrangement.spacedBy(6.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                scene.keyPoints.forEachIndexed { i, pt ->
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(Color(0xFF1E2235).copy(alpha = 0.75f))
                            .padding(horizontal = 12.dp, vertical = 4.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(6.dp)
                                .clip(CircleShape)
                                .background(if (i == 0) Color(0xFF00D2D3) else Color(0xFF7C5CFC))
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = pt,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = Color(0xFFE2E8F0)
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun SubtitleBanner(text: String, style: String) {
    when (style.lowercase()) {
        "karaoke", "karaoke highlight" -> {
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = Color.Black.copy(alpha = 0.85f),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF00D2D3))
            ) {
                Text(
                    text = "▶ $text",
                    color = Color(0xFF00D2D3),
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp)
                )
            }
        }
        "bold neon" -> {
            Surface(
                shape = RoundedCornerShape(8.dp),
                color = Color(0xFF240046).copy(alpha = 0.9f),
                border = androidx.compose.foundation.BorderStroke(1.5.dp, Color(0xFFFF007F))
            ) {
                Text(
                    text = text,
                    color = Color(0xFFFFD60A),
                    fontSize = 13.sp,
                    fontWeight = FontWeight.ExtraBold,
                    fontFamily = FontFamily.Monospace,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                )
            }
        }
        else -> {
            // Modern Pop
            Surface(
                shape = RoundedCornerShape(10.dp),
                color = Color(0xFF161928).copy(alpha = 0.9f),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF7C5CFC).copy(alpha = 0.5f))
            ) {
                Text(
                    text = text,
                    color = Color.White,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Medium,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp)
                )
            }
        }
    }
}

private fun getCanvasBackground(style: String): Brush {
    return when (style.lowercase()) {
        "whiteboard", "whiteboard doodle" -> Brush.verticalGradient(
            colors = listOf(Color(0xFF222831), Color(0xFF1A1C24))
        )
        "isometric 3d" -> Brush.radialGradient(
            colors = listOf(Color(0xFF20163B), Color(0xFF0C091A))
        )
        "minimalist line art" -> Brush.verticalGradient(
            colors = listOf(Color(0xFF121212), Color(0xFF0A0A0A))
        )
        else -> Brush.radialGradient(
            colors = listOf(Color(0xFF1F1B3E), Color(0xFF0B0D16))
        )
    }
}

private fun parseScenes(json: String?, fallbackTopic: String): List<ExplainerScene> {
    if (json.isNullOrBlank()) {
        return listOf(
            ExplainerScene(1, "Introduction: $fallbackTopic", listOf("Core concept breakdown", "Fundamental principles"), "Welcome to this visual explainer on $fallbackTopic.", "lightbulb"),
            ExplainerScene(2, "How It Operates", listOf("Sequential data flow", "Algorithmic execution"), "Here is how the system processes information in real-time.", "network"),
            ExplainerScene(3, "Key Advantages", listOf("Speed & Scalability", "Massive precision gains"), "These breakthroughs unlock significant capabilities for users.", "chart"),
            ExplainerScene(4, "Summary & Future", listOf("Next frontier", "Practical takeaways"), "In conclusion, this technology continues to shape our future.", "rocket")
        )
    }

    try {
        val list = mutableListOf<ExplainerScene>()
        val arr = JSONArray(json)
        for (i in 0 until arr.length()) {
            val obj = arr.getJSONObject(i)
            val kpList = mutableListOf<String>()
            val kpArr = obj.optJSONArray("keyPoints")
            if (kpArr != null) {
                for (j in 0 until kpArr.length()) {
                    kpList.add(kpArr.getString(j))
                }
            } else {
                kpList.add("Key Idea")
            }
            list.add(
                ExplainerScene(
                    sceneNumber = obj.optInt("sceneNumber", i + 1),
                    title = obj.optString("title", "Scene ${i + 1}"),
                    keyPoints = kpList,
                    narration = obj.optString("narration", ""),
                    visualIcon = obj.optString("visualIcon", "lightbulb"),
                    durationSeconds = obj.optInt("durationSeconds", 8)
                )
            )
        }
        return if (list.isNotEmpty()) list else parseScenes(null, fallbackTopic)
    } catch (e: Exception) {
        return parseScenes(null, fallbackTopic)
    }
}

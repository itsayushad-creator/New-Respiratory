package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val StudioViolet = Color(0xFF7C5CFC)
val StudioVioletDark = Color(0xFF5E3FD9)
val StudioCyan = Color(0xFF00D2D3)
val StudioPink = Color(0xFFFF7675)
val StudioAmber = Color(0xFFFF9F43)

val DarkBackground = Color(0xFF0A0C14)
val DarkSurface = Color(0xFF131625)
val DarkSurfaceElevated = Color(0xFF1D2237)
val DarkBorder = Color(0xFF2B3047)

val TextPrimary = Color(0xFFF8FAFC)
val TextSecondary = Color(0xFFA4B0BE)
val TextMuted = Color(0xFF636E72)

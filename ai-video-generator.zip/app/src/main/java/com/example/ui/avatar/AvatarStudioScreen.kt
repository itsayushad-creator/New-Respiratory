package com.example.ui.avatar

import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.rememberAsyncImagePainter
import com.example.audio.LipSyncEngine
import com.example.data.GeminiService
import com.example.db.AppDatabase
import com.example.model.AvatarModel
import com.example.model.VideoProject
import com.example.model.VideoType
import com.example.util.VideoExporter
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.util.UUID

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AvatarStudioScreen(
    database: AppDatabase,
    lipSyncEngine: LipSyncEngine,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    val avatars by database.avatarDao().getAllAvatars().collectAsState(initial = emptyList())

    // If database hasn't prepopulated yet, fallback to sampleAvatars
    val displayAvatars = if (avatars.isNotEmpty()) avatars else AppDatabase.sampleAvatars

    var selectedAvatar by remember(displayAvatars) {
        mutableStateOf(displayAvatars.firstOrNull())
    }

    var scriptText by remember {
        mutableStateOf("Welcome to our official broadcast. With our new AI Avatar engine, your digital twin speaks any language with seamless lip synchronization and natural presence.")
    }

    var selectedLanguage by remember { mutableStateOf("English") }
    var selectedVoiceGender by remember { mutableStateOf("Female") }

    var isCreatingAvatarModalOpen by remember { mutableStateOf(false) }

    var isGeneratingVideo by remember { mutableStateOf(false) }
    var generationStatusText by remember { mutableStateOf("") }
    var generationProgress by remember { mutableFloatStateOf(0f) }

    var activeAvatarVideoProject by remember { mutableStateOf<VideoProject?>(null) }

    val languages = listOf("English", "Spanish", "French", "German", "Hindi", "Japanese", "Chinese", "Portuguese", "Italian")
    val voiceGenders = listOf("Female", "Male", "Warm")

    val sampleScripts = listOf(
        Pair("Product Launch", "We are beyond excited to unveil our groundbreaking next-generation platform, built to empower creators worldwide with seamless generative AI."),
        Pair("News Anchor", "Good evening. Breaking developments today as international tech leaders announce unprecedented breakthroughs in quantum neural systems."),
        Pair("Education Tip", "Did you know that taking brief mental pauses throughout your workflow can boost your problem solving retention by up to forty percent?"),
        Pair("Welcome Greeting", "Hello and welcome! Thank you for joining us today. Let me guide you through the latest updates and exciting features we have lined up.")
    )

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFF0A0C14))
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 12.dp, bottom = 40.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Feature Header Banner
        item {
            Surface(
                shape = RoundedCornerShape(18.dp),
                color = Color(0xFF141726),
                border = BorderStroke(1.dp, Brush.horizontalGradient(listOf(Color(0xFF7C5CFC), Color(0xFF00D2D3)))),
                modifier = Modifier.fillMaxWidth()
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(
                            Brush.linearGradient(
                                colors = listOf(
                                    Color(0xFF7C5CFC).copy(alpha = 0.18f),
                                    Color(0xFF00D2D3).copy(alpha = 0.12f),
                                    Color.Transparent
                                )
                            )
                        )
                        .padding(16.dp)
                ) {
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = Color(0xFF7C5CFC).copy(alpha = 0.25f)
                            ) {
                                Text(
                                    text = "★ AVATAR MODEL VIDEO STUDIO",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF9E86FD),
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                )
                            }
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "AI Avatar Presenter Video",
                            style = MaterialTheme.typography.headlineSmall.copy(
                                color = Color.White,
                                fontWeight = FontWeight.ExtraBold
                            )
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Choose a sample avatar model, create an avatar with AI, or upload your own image. Enter script in any language for accurate lip-syncing!",
                            style = MaterialTheme.typography.bodySmall.copy(color = Color(0xFFA4B0BE))
                        )
                    }
                }
            }
        }

        // Active Player View if an Avatar Video is ready
        if (activeAvatarVideoProject != null) {
            item {
                Text(
                    text = "READY FOR EXPORT & PREVIEW",
                    style = MaterialTheme.typography.labelMedium.copy(
                        color = Color(0xFF00D2D3),
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.1.sp
                    )
                )
                Spacer(modifier = Modifier.height(6.dp))
                AvatarVideoPlayer(
                    project = activeAvatarVideoProject!!,
                    avatar = selectedAvatar,
                    lipSyncEngine = lipSyncEngine,
                    onDownloadClick = {
                        scope.launch {
                            VideoExporter.downloadVideoProject(context, activeAvatarVideoProject!!, {}, {})
                        }
                    },
                    onShareClick = {
                        VideoExporter.shareVideoProject(context, activeAvatarVideoProject!!)
                    }
                )
            }
        }

        // Avatar Model Selection Carousel
        item {
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = Color(0xFF141726),
                border = BorderStroke(1.dp, Color(0xFF262B40)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "CHOOSE AVATAR MODEL",
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = Color(0xFF7C5CFC),
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 1.sp
                            )
                        )

                        // Button to create / upload avatar
                        FilledTonalButton(
                            onClick = { isCreatingAvatarModalOpen = true },
                            colors = ButtonDefaults.filledTonalButtonColors(
                                containerColor = Color(0xFF242A42),
                                contentColor = Color(0xFF00D2D3)
                            ),
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                            modifier = Modifier.height(32.dp).testTag("create_avatar_btn")
                        ) {
                            Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Create / Upload Avatar", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        items(displayAvatars) { avatarItem ->
                            val isSelected = selectedAvatar?.id == avatarItem.id
                            Surface(
                                shape = RoundedCornerShape(14.dp),
                                color = if (isSelected) Color(0xFF23273E) else Color(0xFF0D0F18),
                                border = BorderStroke(
                                    if (isSelected) 2.dp else 1.dp,
                                    if (isSelected) Color(0xFF00D2D3) else Color(0xFF262B40)
                                ),
                                modifier = Modifier
                                    .width(130.dp)
                                    .clickable {
                                        selectedAvatar = avatarItem
                                        selectedVoiceGender = avatarItem.gender
                                    }
                            ) {
                                Column(
                                    modifier = Modifier.padding(8.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(80.dp)
                                            .clip(CircleShape)
                                            .border(2.dp, if (isSelected) Color(0xFF00D2D3) else Color(0xFF333852), CircleShape)
                                    ) {
                                        AvatarImageDisplay(avatar = avatarItem, modifier = Modifier.fillMaxSize())
                                    }

                                    Spacer(modifier = Modifier.height(8.dp))

                                    Text(
                                        text = avatarItem.name,
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = if (isSelected) Color(0xFF00D2D3) else Color.White
                                    )
                                    Text(
                                        text = avatarItem.roleTitle,
                                        fontSize = 10.sp,
                                        color = Color(0xFFA4B0BE),
                                        maxLines = 1,
                                        textAlign = androidx.compose.ui.text.style.TextAlign.Center
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // Script Input Section
        item {
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = Color(0xFF141726),
                border = BorderStroke(1.dp, Color(0xFF262B40)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "AVATAR SCRIPT (ANY LANGUAGE)",
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = Color(0xFF00D2D3),
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 1.sp
                            )
                        )

                        Text(
                            text = "${scriptText.split("\\s+".toRegex()).filter { it.isNotBlank() }.size} words",
                            fontSize = 11.sp,
                            color = Color(0xFFA4B0BE)
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    OutlinedTextField(
                        value = scriptText,
                        onValueChange = { scriptText = it },
                        placeholder = {
                            Text(
                                "Enter the script for your avatar to speak with accurate lip synchronization...",
                                color = Color(0xFF636E72),
                                fontSize = 13.sp
                            )
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(130.dp)
                            .testTag("avatar_script_input"),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White,
                            focusedBorderColor = Color(0xFF7C5CFC),
                            unfocusedBorderColor = Color(0xFF2E334D),
                            focusedContainerColor = Color(0xFF0D0F18),
                            unfocusedContainerColor = Color(0xFF0D0F18)
                        ),
                        shape = RoundedCornerShape(12.dp)
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    Text("Sample Presets", fontSize = 11.sp, color = Color(0xFFA4B0BE))
                    Spacer(modifier = Modifier.height(6.dp))

                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(sampleScripts) { (title, script) ->
                            SuggestionChip(
                                onClick = { scriptText = script },
                                label = { Text(title, fontSize = 11.sp, color = Color(0xFFCBD5E1)) },
                                border = BorderStroke(1.dp, Color(0xFF262B40))
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Language & Voice Settings
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        // Language
                        Column(modifier = Modifier.weight(1.2f)) {
                            Text("Language", fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = Color(0xFFA4B0BE))
                            Spacer(modifier = Modifier.height(6.dp))
                            LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                items(languages) { lang ->
                                    val isSelected = selectedLanguage == lang
                                    Surface(
                                        shape = RoundedCornerShape(8.dp),
                                        color = if (isSelected) Color(0xFF7C5CFC) else Color(0xFF1E2235),
                                        modifier = Modifier.clickable { selectedLanguage = lang }
                                    ) {
                                        Text(
                                            text = lang,
                                            fontSize = 11.sp,
                                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                            color = Color.White,
                                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                                        )
                                    }
                                }
                            }
                        }

                        // Voice Gender
                        Column(modifier = Modifier.weight(0.8f)) {
                            Text("Voice Gender", fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = Color(0xFFA4B0BE))
                            Spacer(modifier = Modifier.height(6.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                voiceGenders.forEach { vg ->
                                    val isSelected = selectedVoiceGender == vg
                                    Surface(
                                        shape = RoundedCornerShape(8.dp),
                                        color = if (isSelected) Color(0xFF00D2D3) else Color(0xFF1E2235),
                                        modifier = Modifier.weight(1f).clickable { selectedVoiceGender = vg }
                                    ) {
                                        Text(
                                            text = vg,
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = if (isSelected) Color(0xFF0A0C14) else Color.White,
                                            textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                                            modifier = Modifier.padding(vertical = 6.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // Submit & Generate Avatar Video Button
        item {
            if (isGeneratingVideo) {
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = Color(0xFF141726),
                    border = BorderStroke(1.dp, Color(0xFF7C5CFC)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        CircularProgressIndicator(
                            progress = { generationProgress },
                            color = Color(0xFF7C5CFC),
                            strokeWidth = 4.dp,
                            modifier = Modifier.size(48.dp)
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = generationStatusText,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                        Text(
                            text = "${(generationProgress * 100).toInt()}% • Neural Viseme Lip-Sync Alignment",
                            fontSize = 11.sp,
                            color = Color(0xFFA4B0BE)
                        )
                    }
                }
            } else {
                Button(
                    onClick = {
                        val avatar = selectedAvatar ?: displayAvatars.first()
                        val wordsCount = scriptText.split("\\s+".toRegex()).size
                        val duration = (wordsCount * 0.45f).toInt().coerceAtLeast(8)

                        scope.launch {
                            isGeneratingVideo = true
                            generationProgress = 0.15f
                            generationStatusText = "Analyzing Phonetic Boundaries & Visemes..."
                            delay(600)

                            generationProgress = 0.50f
                            generationStatusText = "Mapping Facial Keypoints for ${avatar.name}..."
                            delay(700)

                            generationProgress = 0.85f
                            generationStatusText = "Calibrating Neural Lip Sync Engine in $selectedLanguage..."
                            delay(500)

                            val project = VideoProject(
                                title = "Avatar Video: ${avatar.name}",
                                type = VideoType.AVATAR.name,
                                promptOrScript = scriptText,
                                style = "Photorealistic Avatar",
                                aspectRatio = "16:9",
                                durationSeconds = duration,
                                avatarId = avatar.id,
                                avatarName = avatar.name,
                                sourceImageUri = avatar.imageUri,
                                voiceGender = selectedVoiceGender,
                                language = selectedLanguage,
                                status = "READY"
                            )

                            val id = database.videoDao().insertVideo(project)
                            activeAvatarVideoProject = project.copy(id = id)

                            isGeneratingVideo = false
                            Toast.makeText(context, "Avatar Video ready with lip sync! Playing below.", Toast.LENGTH_SHORT).show()
                        }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(56.dp)
                        .testTag("generate_avatar_video_button"),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFF7C5CFC),
                        contentColor = Color.White
                    ),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Icon(Icons.Default.RecordVoiceOver, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Generate Avatar Video with Lip Sync",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }

    // Modal Sheet to Create Own Avatar with AI or Upload Avatar Image
    if (isCreatingAvatarModalOpen) {
        CreateAvatarBottomSheet(
            database = database,
            onDismiss = { isCreatingAvatarModalOpen = false },
            onAvatarCreated = { newAvatar ->
                selectedAvatar = newAvatar
                isCreatingAvatarModalOpen = false
            }
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CreateAvatarBottomSheet(
    database: AppDatabase,
    onDismiss: () -> Unit,
    onAvatarCreated: (AvatarModel) -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var selectedTab by remember { mutableIntStateOf(0) } // 0: AI Generator, 1: Upload Photo

    // AI Generation Fields
    var characteristicsInput by remember {
        mutableStateOf("Professional female presenter in smart modern navy blazer, friendly natural smile, studio lighting")
    }
    var personalityInput by remember {
        mutableStateOf("Authoritative, engaging, warm and trustworthy")
    }
    var avatarGender by remember { mutableStateOf("Female") }
    var isGeneratingAvatarAI by remember { mutableStateOf(false) }

    // Upload Fields
    var customAvatarName by remember { mutableStateOf("") }
    var customRoleTitle by remember { mutableStateOf("Virtual Presenter") }
    var uploadedPhotoUri by remember { mutableStateOf<Uri?>(null) }

    val photoPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) {
            uploadedPhotoUri = uri
        }
    }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        containerColor = Color(0xFF131625),
        dragHandle = { BottomSheetDefaults.DragHandle(color = Color(0xFF7C5CFC)) }
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 12.dp)
                .navigationBarsPadding(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = "Create Your Custom Avatar",
                style = MaterialTheme.typography.titleLarge.copy(
                    color = Color.White,
                    fontWeight = FontWeight.Bold
                )
            )
            Text(
                text = "Build a virtual presenter with AI characteristics or upload your portrait",
                style = MaterialTheme.typography.bodySmall.copy(color = Color(0xFFA4B0BE))
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Tab Selector
            TabRow(
                selectedTabIndex = selectedTab,
                containerColor = Color(0xFF1E2235),
                contentColor = Color(0xFF00D2D3),
                modifier = Modifier.clip(RoundedCornerShape(12.dp))
            ) {
                Tab(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    text = { Text("Generate with AI", fontWeight = FontWeight.Bold) }
                )
                Tab(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    text = { Text("Upload Photo", fontWeight = FontWeight.Bold) }
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            if (selectedTab == 0) {
                // Tab 0: AI Avatar Generation via Characteristics & Personality
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text(
                        text = "1. Characteristics Details",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF00D2D3)
                    )
                    OutlinedTextField(
                        value = characteristicsInput,
                        onValueChange = { characteristicsInput = it },
                        placeholder = { Text("Age, ethnicity, hair, attire, lighting, expressions...") },
                        modifier = Modifier.fillMaxWidth().height(80.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White,
                            focusedBorderColor = Color(0xFF00D2D3),
                            unfocusedBorderColor = Color(0xFF2E334D),
                            focusedContainerColor = Color(0xFF0D0F18),
                            unfocusedContainerColor = Color(0xFF0D0F18)
                        ),
                        shape = RoundedCornerShape(10.dp)
                    )

                    Text(
                        text = "2. Personality & Delivery Style",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF7C5CFC)
                    )
                    OutlinedTextField(
                        value = personalityInput,
                        onValueChange = { personalityInput = it },
                        placeholder = { Text("e.g. Enthusiastic, executive, cheerful, calm, inspiring...") },
                        modifier = Modifier.fillMaxWidth().height(80.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White,
                            focusedBorderColor = Color(0xFF7C5CFC),
                            unfocusedBorderColor = Color(0xFF2E334D),
                            focusedContainerColor = Color(0xFF0D0F18),
                            unfocusedContainerColor = Color(0xFF0D0F18)
                        ),
                        shape = RoundedCornerShape(10.dp)
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        listOf("Female", "Male").forEach { g ->
                            val isSelected = avatarGender == g
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = if (isSelected) Color(0xFF7C5CFC) else Color(0xFF1E2235),
                                modifier = Modifier.weight(1f).clickable { avatarGender = g }
                            ) {
                                Text(
                                    text = g,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White,
                                    textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                                    modifier = Modifier.padding(vertical = 8.dp)
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Button(
                        onClick = {
                            scope.launch {
                                isGeneratingAvatarAI = true
                                val (genName, genRole) = GeminiService.generateAvatarPersona(characteristicsInput, personalityInput)
                                delay(600)

                                val newAvatar = AvatarModel(
                                    id = "custom_ai_${UUID.randomUUID().toString().take(8)}",
                                    name = genName,
                                    roleTitle = genRole,
                                    drawableResName = if (avatarGender == "Male") "avatar_marcus" else "avatar_aria",
                                    isCustom = true,
                                    gender = avatarGender,
                                    personality = personalityInput,
                                    characteristics = characteristicsInput
                                )

                                database.avatarDao().insertAvatar(newAvatar)
                                isGeneratingAvatarAI = false
                                Toast.makeText(context, "Created avatar $genName!", Toast.LENGTH_SHORT).show()
                                onAvatarCreated(newAvatar)
                            }
                        },
                        enabled = !isGeneratingAvatarAI,
                        modifier = Modifier.fillMaxWidth().height(50.dp).testTag("confirm_create_ai_avatar_btn"),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF00D2D3), contentColor = Color(0xFF0A0C14)),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        if (isGeneratingAvatarAI) {
                            CircularProgressIndicator(modifier = Modifier.size(18.dp), color = Color(0xFF0A0C14))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Synthesizing AI Avatar Persona...")
                        } else {
                            Icon(Icons.Default.AutoAwesome, contentDescription = null)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Generate AI Avatar Persona", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            } else {
                // Tab 1: Upload Portrait Photo
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(140.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(Color(0xFF0D0F18))
                            .border(1.dp, Color(0xFF2E334D), RoundedCornerShape(12.dp))
                            .clickable {
                                photoPicker.launch(
                                    PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                )
                            },
                        contentAlignment = Alignment.Center
                    ) {
                        if (uploadedPhotoUri != null) {
                            Image(
                                painter = rememberAsyncImagePainter(model = uploadedPhotoUri),
                                contentDescription = "Uploaded Avatar",
                                contentScale = ContentScale.Crop,
                                modifier = Modifier.fillMaxSize()
                            )
                        } else {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Icon(Icons.Default.CloudUpload, contentDescription = null, tint = Color(0xFF7C5CFC), modifier = Modifier.size(36.dp))
                                Spacer(modifier = Modifier.height(4.dp))
                                Text("Choose Photo from Gallery", color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                                Text("High-resolution front-facing portrait", color = Color(0xFF718096), fontSize = 11.sp)
                            }
                        }
                    }

                    OutlinedTextField(
                        value = customAvatarName,
                        onValueChange = { customAvatarName = it },
                        label = { Text("Avatar Name") },
                        placeholder = { Text("e.g. Maya, Jordan, Alex") },
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White,
                            focusedBorderColor = Color(0xFF7C5CFC),
                            unfocusedBorderColor = Color(0xFF2E334D)
                        )
                    )

                    OutlinedTextField(
                        value = customRoleTitle,
                        onValueChange = { customRoleTitle = it },
                        label = { Text("Role / Title") },
                        placeholder = { Text("e.g. Lead Educator, Global Spokesperson") },
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White,
                            focusedBorderColor = Color(0xFF7C5CFC),
                            unfocusedBorderColor = Color(0xFF2E334D)
                        )
                    )

                    Button(
                        onClick = {
                            val name = if (customAvatarName.isBlank()) "Custom Avatar" else customAvatarName
                            scope.launch {
                                val newAvatar = AvatarModel(
                                    id = "uploaded_${UUID.randomUUID().toString().take(8)}",
                                    name = name,
                                    roleTitle = customRoleTitle,
                                    drawableResName = null,
                                    imageUri = uploadedPhotoUri?.toString(),
                                    isCustom = true,
                                    gender = avatarGender,
                                    personality = "User Uploaded Virtual Human"
                                )
                                database.avatarDao().insertAvatar(newAvatar)
                                Toast.makeText(context, "Added $name to your Avatars!", Toast.LENGTH_SHORT).show()
                                onAvatarCreated(newAvatar)
                            }
                        },
                        modifier = Modifier.fillMaxWidth().height(50.dp).testTag("save_uploaded_avatar_btn"),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF7C5CFC), contentColor = Color.White),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(Icons.Default.Check, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Save Custom Avatar", fontWeight = FontWeight.Bold)
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

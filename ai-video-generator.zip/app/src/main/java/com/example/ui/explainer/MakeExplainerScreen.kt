package com.example.ui.explainer

import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.audio.LipSyncEngine
import com.example.data.GeminiService
import com.example.db.AppDatabase
import com.example.model.VideoProject
import com.example.model.VideoType
import com.example.util.VideoExporter
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MakeExplainerScreen(
    database: AppDatabase,
    lipSyncEngine: LipSyncEngine,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var topic by remember { mutableStateOf("How Quantum Computing Works") }
    var selectedFrameRatio by remember { mutableStateOf("16:9") }
    var selectedLanguage by remember { mutableStateOf("English") }
    var subtitlesOption by remember { mutableStateOf("Modern Pop") } // "Modern Pop", "Karaoke Highlight", "Bold Neon", "Off"
    var selectedAnimationStyle by remember { mutableStateOf("Motion Graphics") }
    var selectedDuration by remember { mutableIntStateOf(60) } // seconds: 30, 60, 90, 120, 180
    var selectedVoiceGender by remember { mutableStateOf("Female") }

    var isGenerating by remember { mutableStateOf(false) }
    var generationPhase by remember { mutableStateOf("") }
    var generationProgress by remember { mutableFloatStateOf(0f) }

    var generatedExplainerProject by remember { mutableStateOf<VideoProject?>(null) }

    val languages = listOf("English", "Spanish", "French", "German", "Hindi", "Japanese", "Chinese", "Portuguese")
    val animationStyles = listOf(
        "Motion Graphics",
        "Whiteboard Doodle",
        "2D Flat Vector",
        "Isometric 3D",
        "Minimalist Line Art"
    )
    val subtitleStyles = listOf("Modern Pop", "Karaoke Highlight", "Bold Neon", "Off")
    val durations = listOf(
        Pair("30s", 30),
        Pair("60s", 60),
        Pair("90s", 90),
        Pair("2m", 120),
        Pair("3m", 180)
    )
    val voiceGenders = listOf("Female", "Male", "Warm")

    val trendingTopics = listOf(
        "How Quantum Computing Works",
        "Why the Sky is Blue",
        "Photosynthesis Explained",
        "Bitcoin & Blockchain Basics",
        "The History of Coffee",
        "How Black Holes Form",
        "Artificial Intelligence 101"
    )

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFF0A0C14))
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 12.dp, bottom = 40.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Explainer Hero Banner
        item {
            Surface(
                shape = RoundedCornerShape(18.dp),
                color = Color(0xFF131728),
                border = BorderStroke(1.dp, Brush.horizontalGradient(listOf(Color(0xFF00D2D3), Color(0xFF7C5CFC)))),
                modifier = Modifier.fillMaxWidth()
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(
                            Brush.linearGradient(
                                colors = listOf(
                                    Color(0xFF00D2D3).copy(alpha = 0.15f),
                                    Color(0xFF7C5CFC).copy(alpha = 0.12f),
                                    Color.Transparent
                                )
                            )
                        )
                        .padding(16.dp)
                ) {
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = Color(0xFF00D2D3).copy(alpha = 0.2f)
                            ) {
                                Text(
                                    text = "★ SPECIAL BONUS FEATURE",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF00D2D3),
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                )
                            }
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "Make Explainer Video",
                            style = MaterialTheme.typography.headlineSmall.copy(
                                color = Color.White,
                                fontWeight = FontWeight.ExtraBold
                            )
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Create a one-click simple graphic animation explainer on any topic with custom voiceover, language & subtitles.",
                            style = MaterialTheme.typography.bodySmall.copy(color = Color(0xFFA4B0BE))
                        )
                    }
                }
            }
        }

        // Active Player View if Explainer Video is generated
        if (generatedExplainerProject != null) {
            item {
                Text(
                    text = "READY FOR BROADCAST",
                    style = MaterialTheme.typography.labelMedium.copy(
                        color = Color(0xFF00D2D3),
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.1.sp
                    )
                )
                Spacer(modifier = Modifier.height(6.dp))
                ExplainerVideoPlayer(
                    project = generatedExplainerProject!!,
                    lipSyncEngine = lipSyncEngine,
                    onDownloadClick = {
                        scope.launch {
                            VideoExporter.downloadVideoProject(context, generatedExplainerProject!!, {}, {})
                        }
                    },
                    onShareClick = {
                        VideoExporter.shareVideoProject(context, generatedExplainerProject!!)
                    }
                )
            }
        }

        // Topic Input Section
        item {
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = Color(0xFF141726),
                border = BorderStroke(1.dp, Color(0xFF262B40)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "EXPLAINER TOPIC",
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = Color(0xFF00D2D3),
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.sp
                        )
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    OutlinedTextField(
                        value = topic,
                        onValueChange = { topic = it },
                        placeholder = { Text("Enter any topic to explain...", color = Color(0xFF636E72)) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("explainer_topic_input"),
                        trailingIcon = {
                            if (topic.isNotBlank()) {
                                IconButton(onClick = { topic = "" }) {
                                    Icon(Icons.Default.Clear, contentDescription = "Clear", tint = Color(0xFFA4B0BE))
                                }
                            }
                        },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White,
                            focusedBorderColor = Color(0xFF00D2D3),
                            unfocusedBorderColor = Color(0xFF2E334D),
                            focusedContainerColor = Color(0xFF0D0F18),
                            unfocusedContainerColor = Color(0xFF0D0F18)
                        ),
                        shape = RoundedCornerShape(12.dp)
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    Text("Popular Topics", fontSize = 11.sp, color = Color(0xFFA4B0BE))
                    Spacer(modifier = Modifier.height(6.dp))

                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(trendingTopics) { t ->
                            SuggestionChip(
                                onClick = { topic = t },
                                label = { Text(t, fontSize = 11.sp, color = Color(0xFFCBD5E1)) },
                                border = BorderStroke(1.dp, Color(0xFF262B40))
                            )
                        }
                    }
                }
            }
        }

        // Customization Style Options
        item {
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = Color(0xFF141726),
                border = BorderStroke(1.dp, Color(0xFF262B40)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "VIDEO CUSTOMISATION STYLE OPTIONS",
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = Color(0xFF7C5CFC),
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.sp
                        )
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    // 1. Frame Ratio
                    Text("1. Frame Ratio", fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = Color(0xFFA4B0BE))
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        listOf(
                            Pair("16:9", "Landscape / YouTube"),
                            Pair("9:16", "Vertical / Shorts"),
                            Pair("1:1", "Square / Feed")
                        ).forEach { (ratio, label) ->
                            val isSelected = selectedFrameRatio == ratio
                            Surface(
                                shape = RoundedCornerShape(10.dp),
                                color = if (isSelected) Color(0xFF20263D) else Color(0xFF0D0F18),
                                border = BorderStroke(1.dp, if (isSelected) Color(0xFF00D2D3) else Color(0xFF262B40)),
                                modifier = Modifier
                                    .weight(1f)
                                    .clickable { selectedFrameRatio = ratio }
                            ) {
                                Column(
                                    modifier = Modifier.padding(vertical = 10.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally
                                ) {
                                    Text(
                                        text = ratio,
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = if (isSelected) Color(0xFF00D2D3) else Color.White
                                    )
                                    Text(
                                        text = label,
                                        fontSize = 9.sp,
                                        color = Color(0xFF718096)
                                    )
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // 2. Animation Style
                    Text("2. Animation Style", fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = Color(0xFFA4B0BE))
                    Spacer(modifier = Modifier.height(6.dp))
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(animationStyles) { animStyle ->
                            val isSelected = selectedAnimationStyle == animStyle
                            Surface(
                                shape = RoundedCornerShape(10.dp),
                                color = if (isSelected) Color(0xFF00D2D3) else Color(0xFF1E2235),
                                border = BorderStroke(1.dp, if (isSelected) Color(0xFF00D2D3) else Color(0xFF2E334D)),
                                modifier = Modifier.clickable { selectedAnimationStyle = animStyle }
                            ) {
                                Text(
                                    text = animStyle,
                                    fontSize = 12.sp,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                    color = if (isSelected) Color(0xFF0A0C14) else Color(0xFFE2E8F0),
                                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // 3. Language & Voice Gender
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        // Language Selector
                        Column(modifier = Modifier.weight(1.2f)) {
                            Text("3. Language", fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = Color(0xFFA4B0BE))
                            Spacer(modifier = Modifier.height(6.dp))
                            LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                items(languages) { lang ->
                                    val isSelected = selectedLanguage == lang
                                    Surface(
                                        shape = RoundedCornerShape(8.dp),
                                        color = if (isSelected) Color(0xFF7C5CFC) else Color(0xFF1E2235),
                                        modifier = Modifier.clickable { selectedLanguage = lang }
                                    ) {
                                        Text(
                                            text = lang,
                                            fontSize = 11.sp,
                                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                            color = Color.White,
                                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                                        )
                                    }
                                }
                            }
                        }

                        // Voice Gender
                        Column(modifier = Modifier.weight(0.8f)) {
                            Text("Voiceover Gender", fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = Color(0xFFA4B0BE))
                            Spacer(modifier = Modifier.height(6.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                voiceGenders.forEach { vg ->
                                    val isSelected = selectedVoiceGender == vg
                                    Surface(
                                        shape = RoundedCornerShape(8.dp),
                                        color = if (isSelected) Color(0xFF00D2D3) else Color(0xFF1E2235),
                                        modifier = Modifier.weight(1f).clickable { selectedVoiceGender = vg }
                                    ) {
                                        Text(
                                            text = vg,
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = if (isSelected) Color(0xFF0A0C14) else Color.White,
                                            textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                                            modifier = Modifier.padding(vertical = 6.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // 4. Subtitles Styling & Duration
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        // Subtitles Style
                        Column(modifier = Modifier.weight(1f)) {
                            Text("4. Subtitles", fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = Color(0xFFA4B0BE))
                            Spacer(modifier = Modifier.height(6.dp))
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = Color(0xFF1E2235),
                                border = BorderStroke(1.dp, Color(0xFF2E334D)),
                                modifier = Modifier.fillMaxWidth().clickable {
                                    val nextIdx = (subtitleStyles.indexOf(subtitlesOption) + 1) % subtitleStyles.size
                                    subtitlesOption = subtitleStyles[nextIdx]
                                }
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(subtitlesOption, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color(0xFF00D2D3))
                                    Icon(Icons.Default.Subtitles, contentDescription = null, tint = Color(0xFF00D2D3), modifier = Modifier.size(16.dp))
                                }
                            }
                        }

                        // Duration
                        Column(modifier = Modifier.weight(1f)) {
                            Text("5. Duration", fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = Color(0xFFA4B0BE))
                            Spacer(modifier = Modifier.height(6.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                durations.forEach { (label, secs) ->
                                    val isSelected = selectedDuration == secs
                                    Surface(
                                        shape = RoundedCornerShape(8.dp),
                                        color = if (isSelected) Color(0xFF7C5CFC) else Color(0xFF1E2235),
                                        modifier = Modifier.weight(1f).clickable { selectedDuration = secs }
                                    ) {
                                        Text(
                                            text = label,
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = Color.White,
                                            textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                                            modifier = Modifier.padding(vertical = 8.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // Generate Explainer Video Action Button
        item {
            if (isGenerating) {
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = Color(0xFF141726),
                    border = BorderStroke(1.dp, Color(0xFF00D2D3)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        CircularProgressIndicator(
                            progress = { generationProgress },
                            color = Color(0xFF00D2D3),
                            strokeWidth = 4.dp,
                            modifier = Modifier.size(48.dp)
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = generationPhase,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                        Text(
                            text = "${(generationProgress * 100).toInt()}% • Creating Graphic Animation Scenes",
                            fontSize = 11.sp,
                            color = Color(0xFFA4B0BE)
                        )
                    }
                }
            } else {
                Button(
                    onClick = {
                        val finalTopic = if (topic.isBlank()) "Artificial Intelligence & Future Tech" else topic
                        scope.launch {
                            isGenerating = true
                            generationProgress = 0.15f
                            generationPhase = "Structuring Multi-Scene Educational Narrative..."
                            delay(500)

                            generationProgress = 0.45f
                            generationPhase = "Generating $selectedLanguage Voiceover & Visual Infographics..."
                            val scenes = GeminiService.generateExplainerStoryboard(
                                topic = finalTopic,
                                animationStyle = selectedAnimationStyle,
                                durationSeconds = selectedDuration,
                                language = selectedLanguage
                            )

                            generationProgress = 0.75f
                            generationPhase = "Composing Kinetic Graphics & Subtitle Synchronization..."
                            delay(600)

                            // Convert scenes to json
                            val scenesJsonArray = JSONArray().apply {
                                scenes.forEach { sc ->
                                    put(JSONObject().apply {
                                        put("sceneNumber", sc.sceneNumber)
                                        put("title", sc.title)
                                        put("narration", sc.narration)
                                        put("visualIcon", sc.visualIcon)
                                        put("durationSeconds", sc.durationSeconds)
                                        put("keyPoints", JSONArray().apply {
                                            sc.keyPoints.forEach { put(it) }
                                        })
                                    })
                                }
                            }

                            generationProgress = 0.95f
                            generationPhase = "Rendering Animation Timeline & Sound..."
                            delay(400)

                            val project = VideoProject(
                                title = "Explainer: $finalTopic",
                                type = VideoType.EXPLAINER.name,
                                promptOrScript = scenes.joinToString("\n\n") { "Scene ${it.sceneNumber}: ${it.narration}" },
                                style = selectedAnimationStyle,
                                aspectRatio = selectedFrameRatio,
                                durationSeconds = selectedDuration,
                                explainerTopic = finalTopic,
                                explainerDataJson = scenesJsonArray.toString(),
                                voiceGender = selectedVoiceGender,
                                language = selectedLanguage,
                                subtitleStyle = subtitlesOption,
                                animationStyle = selectedAnimationStyle,
                                status = "READY"
                            )

                            val id = database.videoDao().insertVideo(project)
                            generatedExplainerProject = project.copy(id = id)

                            isGenerating = false
                            Toast.makeText(context, "Explainer Video Ready! Playing now.", Toast.LENGTH_SHORT).show()
                        }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(56.dp)
                        .testTag("generate_explainer_button"),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFF00D2D3),
                        contentColor = Color(0xFF0A0C14)
                    ),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Icon(Icons.Default.Bolt, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Make Explainer Video in 1-Click",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.ExtraBold
                    )
                }
            }
        }
    }
}

package com.example.ui.videogen

import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.rememberAsyncImagePainter
import com.example.R
import com.example.data.GeminiService
import com.example.db.AppDatabase
import com.example.model.VideoProject
import com.example.model.VideoType
import com.example.util.VideoExporter
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun VideoGenScreen(
    database: AppDatabase,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var selectedMode by remember { mutableStateOf(VideoType.TEXT_TO_VIDEO) }
    var prompt by remember { mutableStateOf("") }
    var motionPrompt by remember { mutableStateOf("") }
    var selectedStyle by remember { mutableStateOf("Cinematic") }
    var selectedAspectRatio by remember { mutableStateOf("16:9") }
    var selectedDuration by remember { mutableIntStateOf(10) }
    var selectedCameraMotion by remember { mutableStateOf("Pan Right") }
    var motionIntensity by remember { mutableFloatStateOf(0.7f) }

    var uploadedImageUri by remember { mutableStateOf<Uri?>(null) }
    var isEnhancingPrompt by remember { mutableStateOf(false) }
    var isGenerating by remember { mutableStateOf(false) }
    var generationStep by remember { mutableStateOf("Initializing Model Weights...") }
    var generationProgress by remember { mutableFloatStateOf(0f) }

    var activeGeneratedProject by remember { mutableStateOf<VideoProject?>(null) }

    // Photo picker for image to video
    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        if (uri != null) {
            uploadedImageUri = uri
        }
    }

    val styles = listOf(
        "Cinematic",
        "Realistic 4K",
        "Cyberpunk",
        "3D Animation",
        "Anime",
        "Studio Commercial",
        "Retro VHS",
        "Fantasy"
    )

    val aspectRatios = listOf("16:9", "9:16", "1:1", "4:3")
    val durations = listOf(5, 10, 15, 30)
    val cameraMotions = listOf("Pan Right", "Zoom In", "Orbit", "Crane Up", "Static Focus")

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFF0A0C14))
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 12.dp, bottom = 40.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Mode Selector: Text to Video vs Image to Video
        item {
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = Color(0xFF141726),
                border = BorderStroke(1.dp, Color(0xFF262B40))
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(4.dp)
                ) {
                    // Text to Video Tab
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(12.dp))
                            .background(
                                if (selectedMode == VideoType.TEXT_TO_VIDEO) Brush.horizontalGradient(
                                    listOf(Color(0xFF7C5CFC), Color(0xFF5E3FD9))
                                ) else Brush.linearGradient(listOf(Color.Transparent, Color.Transparent))
                            )
                            .clickable { selectedMode = VideoType.TEXT_TO_VIDEO }
                            .padding(vertical = 12.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                Icons.Default.Edit,
                                contentDescription = null,
                                tint = if (selectedMode == VideoType.TEXT_TO_VIDEO) Color.White else Color(0xFFA4B0BE),
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "Text to Video",
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp,
                                color = if (selectedMode == VideoType.TEXT_TO_VIDEO) Color.White else Color(0xFFA4B0BE)
                            )
                        }
                    }

                    // Image to Video Tab
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(12.dp))
                            .background(
                                if (selectedMode == VideoType.IMAGE_TO_VIDEO) Brush.horizontalGradient(
                                    listOf(Color(0xFF00D2D3), Color(0xFF0984E3))
                                ) else Brush.linearGradient(listOf(Color.Transparent, Color.Transparent))
                            )
                            .clickable { selectedMode = VideoType.IMAGE_TO_VIDEO }
                            .padding(vertical = 12.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                Icons.Default.Image,
                                contentDescription = null,
                                tint = if (selectedMode == VideoType.IMAGE_TO_VIDEO) Color(0xFF0A0C14) else Color(0xFFA4B0BE),
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "Image to Video",
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp,
                                color = if (selectedMode == VideoType.IMAGE_TO_VIDEO) Color(0xFF0A0C14) else Color(0xFFA4B0BE)
                            )
                        }
                    }
                }
            }
        }

        // Active Player View if a project was just generated
        if (activeGeneratedProject != null) {
            item {
                Text(
                    text = "GENERATED PREVIEW",
                    style = MaterialTheme.typography.labelMedium.copy(
                        color = Color(0xFF00D2D3),
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.1.sp
                    )
                )
                Spacer(modifier = Modifier.height(6.dp))
                VideoPlayerView(
                    project = activeGeneratedProject!!,
                    onDownloadClick = {
                        scope.launch {
                            VideoExporter.downloadVideoProject(context, activeGeneratedProject!!, {}, {})
                        }
                    },
                    onShareClick = {
                        VideoExporter.shareVideoProject(context, activeGeneratedProject!!)
                    }
                )
            }
        }

        // Mode specific inputs
        if (selectedMode == VideoType.TEXT_TO_VIDEO) {
            // Text to Video Prompt Box
            item {
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = Color(0xFF141726),
                    border = BorderStroke(1.dp, Color(0xFF262B40)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "VIDEO PROMPT",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    color = Color(0xFF7C5CFC),
                                    fontWeight = FontWeight.Bold,
                                    letterSpacing = 1.sp
                                )
                            )

                            // AI Enhance Prompt Button
                            FilledTonalButton(
                                onClick = {
                                    scope.launch {
                                        isEnhancingPrompt = true
                                        val enhanced = GeminiService.enhanceVideoPrompt(prompt, selectedStyle, "Text-to-Video")
                                        prompt = enhanced
                                        isEnhancingPrompt = false
                                        Toast.makeText(context, "Enhanced with AI Director!", Toast.LENGTH_SHORT).show()
                                    }
                                },
                                enabled = !isEnhancingPrompt,
                                colors = ButtonDefaults.filledTonalButtonColors(
                                    containerColor = Color(0xFF23273A),
                                    contentColor = Color(0xFF00D2D3)
                                ),
                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                                modifier = Modifier.height(32.dp).testTag("enhance_prompt_btn")
                            ) {
                                if (isEnhancingPrompt) {
                                    CircularProgressIndicator(modifier = Modifier.size(12.dp), strokeWidth = 2.dp, color = Color(0xFF00D2D3))
                                } else {
                                    Icon(Icons.Default.AutoAwesome, contentDescription = null, modifier = Modifier.size(14.dp))
                                }
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("AI Enhance", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        OutlinedTextField(
                            value = prompt,
                            onValueChange = { prompt = it },
                            placeholder = {
                                Text(
                                    "Describe the scene, lighting, subject & motion (e.g. A neon cyber cat running on rooftops in Tokyo during rain)...",
                                    color = Color(0xFF636E72),
                                    fontSize = 13.sp
                                )
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(110.dp)
                                .testTag("text_to_video_prompt_input"),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedTextColor = Color.White,
                                unfocusedTextColor = Color.White,
                                focusedBorderColor = Color(0xFF7C5CFC),
                                unfocusedBorderColor = Color(0xFF2E334D),
                                focusedContainerColor = Color(0xFF0D0F18),
                                unfocusedContainerColor = Color(0xFF0D0F18)
                            ),
                            shape = RoundedCornerShape(12.dp)
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        // Quick Inspiration Prompts
                        LazyRow(
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            val ideas = listOf(
                                "Cyberpunk city flying cars",
                                "Deep sea glowing jellyfish",
                                "Desert dunes drone flight",
                                "Cozy cabin snowy evening",
                                "Golden hour mountain peaks"
                            )
                            items(ideas) { idea ->
                                SuggestionChip(
                                    onClick = { prompt = idea },
                                    label = { Text(idea, fontSize = 11.sp, color = Color(0xFFA4B0BE)) },
                                    border = BorderStroke(1.dp, Color(0xFF262B40))
                                )
                            }
                        }
                    }
                }
            }
        } else {
            // Image to Video Input Box
            item {
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = Color(0xFF141726),
                    border = BorderStroke(1.dp, Color(0xFF262B40)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = "SOURCE IMAGE & MOTION DYNAMICS",
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = Color(0xFF00D2D3),
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 1.sp
                            )
                        )

                        Spacer(modifier = Modifier.height(10.dp))

                        // Image Upload / Preview Box
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(160.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(Color(0xFF0D0F18))
                                .border(1.dp, Color(0xFF2E334D), RoundedCornerShape(12.dp))
                                .clickable {
                                    photoPickerLauncher.launch(
                                        PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                    )
                                },
                            contentAlignment = Alignment.Center
                        ) {
                            if (uploadedImageUri != null) {
                                Image(
                                    painter = rememberAsyncImagePainter(model = uploadedImageUri),
                                    contentDescription = "Source Image",
                                    contentScale = ContentScale.Crop,
                                    modifier = Modifier.fillMaxSize()
                                )
                                Surface(
                                    shape = RoundedCornerShape(8.dp),
                                    color = Color.Black.copy(alpha = 0.7f),
                                    modifier = Modifier.align(Alignment.BottomEnd).padding(8.dp)
                                ) {
                                    Text(
                                        text = "Change Image",
                                        fontSize = 11.sp,
                                        color = Color.White,
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                    )
                                }
                            } else {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Icon(
                                        Icons.Default.AddPhotoAlternate,
                                        contentDescription = "Upload Image",
                                        tint = Color(0xFF00D2D3),
                                        modifier = Modifier.size(36.dp)
                                    )
                                    Spacer(modifier = Modifier.height(6.dp))
                                    Text(
                                        text = "Tap to upload image or photo",
                                        color = Color.White,
                                        fontWeight = FontWeight.SemiBold,
                                        fontSize = 13.sp
                                    )
                                    Text(
                                        text = "Bring any photo to life with AI video motion",
                                        color = Color(0xFF718096),
                                        fontSize = 11.sp
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        // Motion Prompt
                        OutlinedTextField(
                            value = motionPrompt,
                            onValueChange = { motionPrompt = it },
                            placeholder = {
                                Text(
                                    "Motion prompt: gentle camera zoom, hair fluttering in breeze, sunset rays moving...",
                                    color = Color(0xFF636E72),
                                    fontSize = 12.sp
                                )
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(72.dp),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedTextColor = Color.White,
                                unfocusedTextColor = Color.White,
                                focusedBorderColor = Color(0xFF00D2D3),
                                unfocusedBorderColor = Color(0xFF2E334D),
                                focusedContainerColor = Color(0xFF0D0F18),
                                unfocusedContainerColor = Color(0xFF0D0F18)
                            ),
                            shape = RoundedCornerShape(10.dp)
                        )

                        Spacer(modifier = Modifier.height(10.dp))

                        // Motion Intensity Slider
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("Motion Energy", fontSize = 12.sp, color = Color(0xFFA4B0BE))
                            Text(
                                text = if (motionIntensity < 0.4f) "Subtle" else if (motionIntensity < 0.8f) "Cinematic" else "Hyper Dynamic",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF00D2D3)
                            )
                        }
                        Slider(
                            value = motionIntensity,
                            onValueChange = { motionIntensity = it },
                            colors = SliderDefaults.colors(
                                thumbColor = Color(0xFF00D2D3),
                                activeTrackColor = Color(0xFF00D2D3),
                                inactiveTrackColor = Color(0xFF262B40)
                            )
                        )
                    }
                }
            }
        }

        // Style Customization Section
        item {
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = Color(0xFF141726),
                border = BorderStroke(1.dp, Color(0xFF262B40)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "STYLE CUSTOMIZATION",
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = Color(0xFF7C5CFC),
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.sp
                        )
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(styles) { style ->
                            val isSelected = selectedStyle == style
                            Surface(
                                shape = RoundedCornerShape(10.dp),
                                color = if (isSelected) Color(0xFF7C5CFC) else Color(0xFF1E2235),
                                border = BorderStroke(1.dp, if (isSelected) Color(0xFF9E86FD) else Color(0xFF2E334D)),
                                modifier = Modifier.clickable { selectedStyle = style }
                            ) {
                                Text(
                                    text = style,
                                    color = if (isSelected) Color.White else Color(0xFFCBD5E1),
                                    fontSize = 12.sp,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp)
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Aspect Ratio Selector
                    Text("Frame Ratio", fontSize = 12.sp, color = Color(0xFFA4B0BE))
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        aspectRatios.forEach { ratio ->
                            val isSelected = selectedAspectRatio == ratio
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = if (isSelected) Color(0xFF23273A) else Color(0xFF0D0F18),
                                border = BorderStroke(1.dp, if (isSelected) Color(0xFF00D2D3) else Color(0xFF262B40)),
                                modifier = Modifier
                                    .weight(1f)
                                    .clickable { selectedAspectRatio = ratio }
                            ) {
                                Column(
                                    modifier = Modifier.padding(vertical = 8.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally
                                ) {
                                    Text(
                                        text = ratio,
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = if (isSelected) Color(0xFF00D2D3) else Color.White
                                    )
                                    Text(
                                        text = if (ratio == "16:9") "Cinema" else if (ratio == "9:16") "Reels" else if (ratio == "1:1") "Square" else "Standard",
                                        fontSize = 9.sp,
                                        color = Color(0xFF718096)
                                    )
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Duration & Camera Motion in 2 columns
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        // Duration column
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Duration", fontSize = 12.sp, color = Color(0xFFA4B0BE))
                            Spacer(modifier = Modifier.height(6.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                durations.forEach { dur ->
                                    val isSelected = selectedDuration == dur
                                    Surface(
                                        shape = RoundedCornerShape(8.dp),
                                        color = if (isSelected) Color(0xFF7C5CFC) else Color(0xFF1E2235),
                                        modifier = Modifier.weight(1f).clickable { selectedDuration = dur }
                                    ) {
                                        Text(
                                            text = "${dur}s",
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = Color.White,
                                            textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                                            modifier = Modifier.padding(vertical = 8.dp)
                                        )
                                    }
                                }
                            }
                        }

                        // Camera Motion column
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Camera Motion", fontSize = 12.sp, color = Color(0xFFA4B0BE))
                            Spacer(modifier = Modifier.height(6.dp))
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = Color(0xFF1E2235),
                                border = BorderStroke(1.dp, Color(0xFF2E334D)),
                                modifier = Modifier.fillMaxWidth().clickable {
                                    val nextIdx = (cameraMotions.indexOf(selectedCameraMotion) + 1) % cameraMotions.size
                                    selectedCameraMotion = cameraMotions[nextIdx]
                                }
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(selectedCameraMotion, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color(0xFF00D2D3))
                                    Icon(Icons.Default.Videocam, contentDescription = null, tint = Color(0xFF00D2D3), modifier = Modifier.size(16.dp))
                                }
                            }
                        }
                    }
                }
            }
        }

        // Generate Action Button or Progress Banner
        item {
            if (isGenerating) {
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = Color(0xFF141726),
                    border = BorderStroke(1.dp, Color(0xFF7C5CFC)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        CircularProgressIndicator(
                            progress = { generationProgress },
                            color = Color(0xFF00D2D3),
                            strokeWidth = 4.dp,
                            modifier = Modifier.size(48.dp)
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = generationStep,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                        Text(
                            text = "${(generationProgress * 100).toInt()}% • CineAI Neural Engine",
                            fontSize = 11.sp,
                            color = Color(0xFFA4B0BE)
                        )
                    }
                }
            } else {
                Button(
                    onClick = {
                        val inputPrompt = if (selectedMode == VideoType.TEXT_TO_VIDEO) {
                            if (prompt.isBlank()) "Futuristic neon city with cinematic rain reflections" else prompt
                        } else {
                            if (motionPrompt.isBlank()) "Dynamic cinematic pan and camera drift" else motionPrompt
                        }

                        scope.launch {
                            isGenerating = true
                            generationProgress = 0.1f
                            generationStep = "Prompt Conditioning & Token Alignment..."
                            delay(600)

                            generationProgress = 0.35f
                            generationStep = "Diffusion Sampling & Latent Space Trajectory..."
                            delay(800)

                            generationProgress = 0.70f
                            generationStep = "Temporal Motion Consistency & Flow Vectors..."
                            delay(700)

                            generationProgress = 0.95f
                            generationStep = "Encoding 4K 60FPS Video Stream..."
                            delay(500)

                            val newProject = VideoProject(
                                title = if (selectedMode == VideoType.TEXT_TO_VIDEO) "Text Video: ${inputPrompt.take(24)}" else "Image Motion Video",
                                type = selectedMode.name,
                                promptOrScript = inputPrompt,
                                style = selectedStyle,
                                aspectRatio = selectedAspectRatio,
                                durationSeconds = selectedDuration,
                                sourceImageUri = uploadedImageUri?.toString(),
                                status = "READY"
                            )

                            val insertedId = database.videoDao().insertVideo(newProject)
                            activeGeneratedProject = newProject.copy(id = insertedId)

                            isGenerating = false
                            Toast.makeText(context, "Video Ready! Scroll to preview.", Toast.LENGTH_SHORT).show()
                        }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(54.dp)
                        .testTag("generate_video_button"),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFF7C5CFC),
                        contentColor = Color.White
                    ),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Icon(Icons.Default.MovieFilter, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (selectedMode == VideoType.TEXT_TO_VIDEO) "Generate Text to Video" else "Generate Image to Video",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}

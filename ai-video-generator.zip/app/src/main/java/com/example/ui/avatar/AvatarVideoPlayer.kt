package com.example.ui.avatar

import android.content.Context
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.rememberAsyncImagePainter
import com.example.R
import com.example.audio.LipSyncEngine
import com.example.audio.VisemeShape
import com.example.model.AvatarModel
import com.example.model.VideoProject
import com.example.util.VideoExporter
import kotlinx.coroutines.launch
import java.io.File

@Composable
fun AvatarVideoPlayer(
    project: VideoProject,
    avatar: AvatarModel?,
    lipSyncEngine: LipSyncEngine,
    onDownloadClick: () -> Unit,
    onShareClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val lipSyncState by lipSyncEngine.state.collectAsState()
    val scope = rememberCoroutineScope()

    var playbackSpeed by remember { mutableFloatStateOf(1.0f) }
    var showSpeedDialog by remember { mutableStateOf(false) }

    // Start speaking automatically when player launches
    LaunchedEffect(project.id) {
        lipSyncEngine.setLanguage(project.language)
        lipSyncEngine.setVoiceGender(project.voiceGender)
        lipSyncEngine.speak(project.promptOrScript)
    }

    DisposableEffect(Unit) {
        onDispose {
            lipSyncEngine.stop()
        }
    }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .background(Color(0xFF12141F))
            .border(1.dp, Color(0xFF2E334D), RoundedCornerShape(20.dp))
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Player Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(10.dp)
                        .clip(CircleShape)
                        .background(if (lipSyncState.isSpeaking) Color(0xFF00E676) else Color(0xFFFF5252))
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = if (lipSyncState.isSpeaking) "LIP-SYNC BROADCASTING" else "READY",
                    style = MaterialTheme.typography.labelSmall.copy(
                        color = if (lipSyncState.isSpeaking) Color(0xFF00E676) else Color(0xFFA4B0BE),
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.2.sp
                    )
                )
            }

            Row {
                IconButton(
                    onClick = onShareClick,
                    modifier = Modifier.size(36.dp).testTag("avatar_share_btn")
                ) {
                    Icon(Icons.Default.Share, contentDescription = "Share Video", tint = Color.White)
                }
                Spacer(modifier = Modifier.width(4.dp))
                FilledTonalButton(
                    onClick = onDownloadClick,
                    modifier = Modifier.height(36.dp).testTag("avatar_download_btn"),
                    colors = ButtonDefaults.filledTonalButtonColors(
                        containerColor = Color(0xFF7C5CFC),
                        contentColor = Color.White
                    ),
                    contentPadding = PaddingValues(horizontal = 12.dp)
                ) {
                    Icon(Icons.Default.Download, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Download", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Avatar Stage (Container)
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(340.dp)
                .clip(RoundedCornerShape(16.dp))
                .background(
                    Brush.verticalGradient(
                        colors = listOf(Color(0xFF1E2235), Color(0xFF0A0C14))
                    )
                )
                .border(1.dp, Brush.horizontalGradient(listOf(Color(0xFF7C5CFC).copy(alpha = 0.4f), Color(0xFF00D2D3).copy(alpha = 0.4f))), RoundedCornerShape(16.dp)),
            contentAlignment = Alignment.Center
        ) {
            // Animated Avatar Portrait with head tilt & viseme mouth overlay
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .rotate(lipSyncState.headTiltX),
                contentAlignment = Alignment.Center
            ) {
                // Background subtle avatar stage glow
                Canvas(modifier = Modifier.fillMaxSize()) {
                    drawCircle(
                        brush = Brush.radialGradient(
                            colors = listOf(Color(0xFF7C5CFC).copy(alpha = 0.25f), Color.Transparent),
                            center = center,
                            radius = size.minDimension * 0.6f
                        )
                    )
                }

                // Avatar Image
                AvatarImageDisplay(
                    avatar = avatar,
                    modifier = Modifier
                        .fillMaxSize()
                        .offset(y = (lipSyncState.headTiltY * 2).dp)
                )

                // Reactive Viseme Lip-Sync Mouth Overlay
                Canvas(
                    modifier = Modifier
                        .align(Alignment.Center)
                        .offset(y = 52.dp + (lipSyncState.headTiltY * 2).dp)
                        .size(width = 72.dp, height = 36.dp)
                ) {
                    if (lipSyncState.isSpeaking && lipSyncState.mouthOpenAmount > 0.05f) {
                        val openAmt = lipSyncState.mouthOpenAmount
                        val widthScale = lipSyncState.mouthWidthFactor
                        val mouthW = size.width * 0.7f * widthScale
                        val mouthH = size.height * openAmt * 0.85f

                        val cx = size.width / 2f
                        val cy = size.height / 2f

                        // Inner mouth cavity
                        drawRoundRect(
                            color = Color(0xFF2C0A0A),
                            topLeft = Offset(cx - mouthW / 2, cy - mouthH / 2),
                            size = Size(mouthW, mouthH),
                            cornerRadius = CornerRadius(mouthW / 2, mouthH / 2)
                        )

                        // Upper Teeth strip
                        if (openAmt > 0.25f) {
                            val teethW = mouthW * 0.65f
                            val teethH = mouthH * 0.28f
                            drawRoundRect(
                                color = Color(0xFFFAFAFA),
                                topLeft = Offset(cx - teethW / 2, cy - mouthH / 2),
                                size = Size(teethW, teethH),
                                cornerRadius = CornerRadius(2f, 2f)
                            )
                        }

                        // Tongue
                        if (openAmt > 0.4f) {
                            val tongueW = mouthW * 0.5f
                            val tongueH = mouthH * 0.35f
                            drawOval(
                                color = Color(0xFFD63031),
                                topLeft = Offset(cx - tongueW / 2, cy + mouthH / 2 - tongueH),
                                size = Size(tongueW, tongueH)
                            )
                        }

                        // Outer lip contour
                        drawRoundRect(
                            color = Color(0xFFC0392B).copy(alpha = 0.85f),
                            topLeft = Offset(cx - mouthW / 2, cy - mouthH / 2),
                            size = Size(mouthW, mouthH),
                            cornerRadius = CornerRadius(mouthW / 2, mouthH / 2),
                            style = Stroke(width = 3f)
                        )
                    }
                }

                // Natural Blink Overlay
                if (lipSyncState.isBlinking) {
                    Canvas(
                        modifier = Modifier
                            .align(Alignment.Center)
                            .offset(y = (-20).dp)
                            .size(width = 110.dp, height = 24.dp)
                    ) {
                        // Left & right eyelid curves
                        drawArc(
                            color = Color(0xFF3D271D),
                            startAngle = 0f,
                            sweepAngle = 180f,
                            useCenter = false,
                            topLeft = Offset(10f, 6f),
                            size = Size(36f, 14f),
                            style = Stroke(width = 4f)
                        )
                        drawArc(
                            color = Color(0xFF3D271D),
                            startAngle = 0f,
                            sweepAngle = 180f,
                            useCenter = false,
                            topLeft = Offset(size.width - 46f, 6f),
                            size = Size(36f, 14f),
                            style = Stroke(width = 4f)
                        )
                    }
                }
            }

            // Audio Waveform Equalizer overlay at bottom
            Box(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp)
            ) {
                Canvas(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(28.dp)
                ) {
                    val barCount = lipSyncState.audioAmplitudes.size
                    val spacing = 6f
                    val totalSpacing = spacing * (barCount - 1)
                    val barWidth = (size.width - totalSpacing) / barCount

                    lipSyncState.audioAmplitudes.forEachIndexed { i, amp ->
                        val barHeight = (size.height * amp).coerceAtLeast(4f)
                        val x = i * (barWidth + spacing)
                        val y = (size.height - barHeight) / 2

                        drawRoundRect(
                            brush = Brush.verticalGradient(
                                colors = listOf(Color(0xFF00D2D3), Color(0xFF7C5CFC))
                            ),
                            topLeft = Offset(x, y),
                            size = Size(barWidth, barHeight),
                            cornerRadius = CornerRadius(4f, 4f)
                        )
                    }
                }
            }

            // Watermark / Studio Badge
            Surface(
                modifier = Modifier
                    .align(Alignment.TopStart)
                    .padding(12.dp),
                shape = RoundedCornerShape(8.dp),
                color = Color.Black.copy(alpha = 0.65f)
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        Icons.Default.RecordVoiceOver,
                        contentDescription = null,
                        tint = Color(0xFF00D2D3),
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = avatar?.name ?: "AI Presenter",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Dynamic Subtitle / Teleprompter Display
        Surface(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp),
            color = Color(0xFF181B29),
            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF262A40))
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "LIVE SCRIPT CAPTION",
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = Color(0xFF7C5CFC),
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.sp
                        )
                    )
                    Text(
                        text = "${((lipSyncState.progress) * 100).toInt()}%",
                        style = MaterialTheme.typography.labelSmall.copy(color = Color(0xFFA4B0BE))
                    )
                }
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = if (lipSyncState.currentWord.isNotBlank()) {
                        "Speaking: \"${lipSyncState.currentWord}\"..."
                    } else {
                        "\"${project.promptOrScript}\""
                    },
                    style = MaterialTheme.typography.bodyMedium.copy(
                        color = Color.White,
                        fontWeight = FontWeight.Medium
                    ),
                    maxLines = 3
                )
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Playback Timeline Slider
        Slider(
            value = lipSyncState.progress,
            onValueChange = {},
            modifier = Modifier.fillMaxWidth().testTag("avatar_progress_slider"),
            colors = SliderDefaults.colors(
                thumbColor = Color(0xFF00D2D3),
                activeTrackColor = Color(0xFF7C5CFC),
                inactiveTrackColor = Color(0xFF262A40)
            )
        )

        // Player Controls (Play, Pause, Replay, Speed)
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Speed Chip
            FilledTonalButton(
                onClick = {
                    playbackSpeed = when (playbackSpeed) {
                        0.75f -> 1.0f
                        1.0f -> 1.25f
                        1.25f -> 1.5f
                        else -> 0.75f
                    }
                    lipSyncEngine.setPlaybackRate(playbackSpeed)
                },
                modifier = Modifier.height(36.dp),
                colors = ButtonDefaults.filledTonalButtonColors(
                    containerColor = Color(0xFF23273A),
                    contentColor = Color(0xFF00D2D3)
                ),
                contentPadding = PaddingValues(horizontal = 10.dp)
            ) {
                Text("${playbackSpeed}x", fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }

            // Center Media Controls
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(
                    onClick = {
                        lipSyncEngine.stop()
                        lipSyncEngine.speak(project.promptOrScript)
                    },
                    modifier = Modifier.size(42.dp).testTag("avatar_replay_btn")
                ) {
                    Icon(Icons.Default.Replay, contentDescription = "Restart", tint = Color.White)
                }

                Spacer(modifier = Modifier.width(8.dp))

                FloatingActionButton(
                    onClick = {
                        if (lipSyncState.isSpeaking) {
                            lipSyncEngine.pause()
                        } else if (lipSyncState.isPaused) {
                            lipSyncEngine.resume()
                        } else {
                            lipSyncEngine.speak(project.promptOrScript)
                        }
                    },
                    containerColor = Color(0xFF7C5CFC),
                    contentColor = Color.White,
                    modifier = Modifier.size(54.dp).testTag("avatar_play_pause_btn")
                ) {
                    Icon(
                        imageVector = if (lipSyncState.isSpeaking) Icons.Default.Pause else Icons.Default.PlayArrow,
                        contentDescription = if (lipSyncState.isSpeaking) "Pause" else "Play",
                        modifier = Modifier.size(28.dp)
                    )
                }

                Spacer(modifier = Modifier.width(8.dp))

                IconButton(
                    onClick = { lipSyncEngine.stop() },
                    modifier = Modifier.size(42.dp).testTag("avatar_stop_btn")
                ) {
                    Icon(Icons.Default.Stop, contentDescription = "Stop", tint = Color(0xFFA4B0BE))
                }
            }

            // Language & Voice indicator
            Surface(
                shape = RoundedCornerShape(8.dp),
                color = Color(0xFF23273A)
            ) {
                Text(
                    text = "${project.language} • ${project.voiceGender}",
                    fontSize = 11.sp,
                    color = Color(0xFFA4B0BE),
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp)
                )
            }
        }
    }
}

@Composable
fun AvatarImageDisplay(avatar: AvatarModel?, modifier: Modifier = Modifier) {
    val context = LocalContext.current

    when {
        avatar?.imageUri != null -> {
            val uriFile = File(avatar.imageUri)
            val model = if (uriFile.exists()) uriFile else avatar.imageUri
            Image(
                painter = rememberAsyncImagePainter(model = model),
                contentDescription = avatar.name,
                contentScale = ContentScale.Crop,
                modifier = modifier
            )
        }
        avatar?.drawableResName != null -> {
            val resId = remember(avatar.drawableResName) {
                context.resources.getIdentifier(avatar.drawableResName, "drawable", context.packageName)
            }
            if (resId != 0) {
                Image(
                    painter = painterResource(id = resId),
                    contentDescription = avatar.name,
                    contentScale = ContentScale.Crop,
                    modifier = modifier
                )
            } else {
                AvatarPlaceholderFallback(avatar.name, modifier)
            }
        }
        else -> {
            AvatarPlaceholderFallback(avatar?.name ?: "Presenter", modifier)
        }
    }
}

@Composable
fun AvatarPlaceholderFallback(name: String, modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .background(
                Brush.linearGradient(
                    colors = listOf(Color(0xFF2E1C4E), Color(0xFF1B2349))
                )
            ),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(
                Icons.Default.AccountCircle,
                contentDescription = null,
                tint = Color(0xFF8C72FF),
                modifier = Modifier.size(100.dp)
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = name,
                style = MaterialTheme.typography.titleMedium.copy(
                    color = Color.White,
                    fontWeight = FontWeight.Bold
                )
            )
            Text(
                text = "AI Virtual Human",
                style = MaterialTheme.typography.bodySmall.copy(color = Color(0xFF00D2D3))
            )
        }
    }
}
